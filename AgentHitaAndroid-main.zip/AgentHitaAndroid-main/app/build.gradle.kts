﻿import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.kapt")
}

val secrets = Properties().apply {
    val f = rootProject.file("secrets.properties")
        .takeIf { it.exists() }
        ?: rootProject.file("../AgentHitaAndroidConfig/secrets.properties")
    if (f.exists()) load(f.inputStream())
}

val devSecrets = Properties().apply {
    val f = rootProject.file("secrets.dev.properties")
        .takeIf { it.exists() }
        ?: rootProject.file("../AgentHitaAndroidConfig/secrets.dev.properties")
    if (f.exists()) load(f.inputStream())
}

android {
    namespace = "com.agenthita.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.agenthita.app"
        minSdk = 26
        targetSdk = 36
        versionCode = 38
        versionName = "1.0.38"

        buildConfigField("String", "FEEDBACK_API_URL",        "\"${secrets.getProperty("FEEDBACK_API_URL",        "https://api.agenthita.org/feedback")}\"")
        buildConfigField("String", "ALERT_API_URL",           "\"${secrets.getProperty("ALERT_API_URL",           "https://api.agenthita.org/alert")}\"")
        buildConfigField("String", "TELEMETRY_API_URL",       "\"${secrets.getProperty("TELEMETRY_API_URL",       "https://api.agenthita.org/telemetry")}\"")
        buildConfigField("String", "DEVICE_REGISTER_URL",     "\"${secrets.getProperty("DEVICE_REGISTER_URL",     "https://api.agenthita.org/device/register")}\"")
        buildConfigField("String", "DEVICE_PING_URL",         "\"${secrets.getProperty("DEVICE_PING_URL",         "https://api.agenthita.org/device/ping")}\"")
        buildConfigField("String", "MODEL_SIGNED_URL_ENDPOINT","\"${secrets.getProperty("MODEL_SIGNED_URL_ENDPOINT","https://api.agenthita.org/model/download-url")}\"")
        buildConfigField("String", "REMOTE_CONFIG_URL",       "\"${secrets.getProperty("REMOTE_CONFIG_URL",       "https://www.agenthita.org/app_config.json")}\"")
        buildConfigField("Long",   "CLOUD_PROJECT_NUMBER",
            "${secrets.getProperty("CLOUD_PROJECT_NUMBER", "0")}L")
        // Authorizes AgentHitaFeedbackService's PLAY_INTEGRITY_REQUIRE_TOKEN=false
        // unattested-registration bypass — see DeviceTokenManager.register() and that
        // service's PlayIntegrityService/AppleAttestationService. Blank by default;
        // only ever set (via devSecrets below) in the debug build type against
        // api-dev.agenthita.org.
        buildConfigField("String", "DEV_REGISTRATION_KEY", "\"${secrets.getProperty("DEV_REGISTRATION_KEY", "")}\"")

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    signingConfigs {
        create("release") {
            val ksFile = secrets.getProperty("KEYSTORE_FILE", "")
            if (ksFile.isNotEmpty()) {
                // CI: config repo checked out at AgentHitaAndroidConfig/ inside workspace → fromRoot hits
                // Local: config repo sits one level up at ../AgentHitaAndroidConfig/ → fromParent hits
                val fromRoot   = rootProject.file(ksFile)
                val fromParent = rootProject.file("../$ksFile")
                val fromModule = file(ksFile)
                storeFile = listOf(fromRoot, fromParent, fromModule).firstOrNull { it.exists() }
            }
            storePassword = secrets.getProperty("KEYSTORE_PASSWORD", "")
            keyAlias      = secrets.getProperty("KEY_ALIAS", "")
            keyPassword   = secrets.getProperty("KEY_PASSWORD", "")
        }
    }

    buildTypes {
        debug {
            buildConfigField("String", "FEEDBACK_API_URL",
                "\"${devSecrets.getProperty("FEEDBACK_API_URL",         "https://api-dev.agenthita.org/feedback")}\"")
            buildConfigField("String", "ALERT_API_URL",
                "\"${devSecrets.getProperty("ALERT_API_URL",            "https://api-dev.agenthita.org/alert")}\"")
            buildConfigField("String", "TELEMETRY_API_URL",
                "\"${devSecrets.getProperty("TELEMETRY_API_URL",        "https://api-dev.agenthita.org/telemetry")}\"")
            buildConfigField("String", "DEVICE_REGISTER_URL",
                "\"${devSecrets.getProperty("DEVICE_REGISTER_URL",      "https://api-dev.agenthita.org/device/register")}\"")
            buildConfigField("String", "DEVICE_PING_URL",
                "\"${devSecrets.getProperty("DEVICE_PING_URL",          "https://api-dev.agenthita.org/device/ping")}\"")
            buildConfigField("String", "MODEL_SIGNED_URL_ENDPOINT",
                "\"${devSecrets.getProperty("MODEL_SIGNED_URL_ENDPOINT","https://api-dev.agenthita.org/model/download-url")}\"")
            buildConfigField("String", "REMOTE_CONFIG_URL",
                "\"${devSecrets.getProperty("REMOTE_CONFIG_URL",        "https://www.agenthita.org/dev/app_config.json")}\"")
            buildConfigField("Long", "CLOUD_PROJECT_NUMBER", "0L")
            buildConfigField("String", "DEV_REGISTRATION_KEY",
                "\"${devSecrets.getProperty("DEV_REGISTRATION_KEY", "")}\"")
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            signingConfig = signingConfigs.getByName("release")
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    testOptions {
        unitTests {
            isReturnDefaultValues = true
        }
    }
    buildFeatures {
        viewBinding = true
        buildConfig = true
    }
    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
            excludes += "META-INF/NOTICE.md"
            excludes += "META-INF/LICENSE.md"
        }
        jniLibs {
            useLegacyPackaging = false  // Required for 16KB page size alignment (Android 15+)
        }
    }
}

kotlin {
    jvmToolchain {
        languageVersion.set(JavaLanguageVersion.of(21))
    }
}

dependencies {
    // Hita Safety SDK — shared detection engine (also used by the iOS build)
    implementation("com.agenthita.sdk:HitaSafetySDK-android:0.1.0")

    // Core
    implementation("androidx.core:core-ktx:1.18.0")
    implementation("androidx.activity:activity-ktx:1.13.0")
    implementation("androidx.appcompat:appcompat:1.7.1")
    implementation("com.google.android.material:material:1.14.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.7.0")

    // Coroutines
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")

    // Room + SQLCipher (encrypted local storage)
    implementation("androidx.room:room-runtime:2.7.0")
    implementation("androidx.room:room-ktx:2.7.0")
    kapt("androidx.room:room-compiler:2.7.0")
    implementation("net.zetetic:sqlcipher-android:4.9.0")
    implementation("androidx.sqlite:sqlite:2.6.2")
    implementation("androidx.sqlite:sqlite-ktx:2.4.0")

    // Encrypted SharedPreferences (consent state)
    implementation("androidx.security:security-crypto:1.1.0-alpha06")

    // WorkManager (background guardian alert dispatch)
    implementation("androidx.work:work-runtime-ktx:2.9.0")

    // JavaMail Android port (guardian email alerts)
    implementation("com.sun.mail:android-mail:1.6.7")
    implementation("com.sun.mail:android-activation:1.6.7")

    // Play Integrity — device/app attestation at registration time
    implementation("com.google.android.play:integrity:1.4.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-play-services:1.7.3")

    // MediaPipe LLM Inference — Gemma on-device classifier (0.10.22+ required for Gemma 3)
    implementation("com.google.mediapipe:tasks-genai:0.10.22")

    // Lifecycle (repeatOnLifecycle for dashboard UI)
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.7.0")

    // RecyclerView (recent events list)
    implementation("androidx.recyclerview:recyclerview:1.3.2")

    // Unit tests
    testImplementation("junit:junit:4.13.2")

    // Instrumented tests — on-device model comparison suite (ModelComparisonSuite)
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test:runner:1.6.2")
}

package com.agenthita.app.consent

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.agenthita.app.config.RemoteConfig

/**
 * Implements the anti-coercion design patterns specified in consent.html.
 *
 * Safeguard #3 — Safe Exit Pathway:
 *   If a monitored user searches for escape/help terms, surface resources locally
 *   WITHOUT logging the search or triggering any guardian alert.
 *
 * Safeguard #4 — Periodic Autonomy Prompts:
 *   Every 90 days, check whether the user still consents to guardian alerts.
 *   Response is never shared with the guardian.
 */
class AntiCoercionMonitor(
    private val context: Context,
    private val consentManager: ConsentManager
) {
    /**
     * Call this before passing any text to the detection pipeline.
     * If the query matches safe-exit terms, suppress analysis and return help resources.
     */
    fun checkForSafeExitIntent(query: String): SafeExitResult {
        val lower = query.lowercase()
        val isSafeExitQuery = safeExitTerms.any { lower.contains(it) }
        return if (isSafeExitQuery) {
            val resources = RemoteConfig.helpResources.map { HelpResource(it.name, it.url) }
            SafeExitResult(shouldSuppressAnalysis = true, resources = resources)
        } else {
            SafeExitResult(shouldSuppressAnalysis = false)
        }
    }

    /** Returns true if it's time to show the 90-day private autonomy check-in. */
    fun shouldShowAutonomyPrompt(): Boolean =
        consentManager.isGuardianAlertsEnabled && consentManager.isDueForAutonomyPrompt()

    fun recordAutonomyPromptShown() {
        consentManager.lastAutonomyPromptMs = System.currentTimeMillis()
    }

    /** Opens a help URL without triggering any detection or guardian notification. */
    fun openHelpResource(url: String) {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    }

    // Terms that indicate the user may be looking for help or trying to escape monitoring.
    // Keeping this list conservative — false positives here mean suppressed detection,
    // which is safer than false negatives (alerting the guardian about a distress search).
    private val safeExitTerms = listOf(
        "am i being tracked", "am i being monitored", "how to remove monitoring",
        "domestic abuse help", "how to remove agent hita", "is my phone monitored",
        "national domestic violence", "abuse hotline", "how to get help",
        "stalkerware", "spyware on my phone", "coercive control",
        "my partner is controlling me", "i feel unsafe"
    )

}

data class SafeExitResult(
    val shouldSuppressAnalysis: Boolean,
    val resources: List<HelpResource> = emptyList()
)

data class HelpResource(val name: String, val url: String)

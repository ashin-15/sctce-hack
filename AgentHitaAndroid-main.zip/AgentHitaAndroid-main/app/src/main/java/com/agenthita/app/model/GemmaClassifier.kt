package com.agenthita.app.model

import android.content.ContentUris
import android.content.Context
import android.provider.MediaStore
import com.agenthita.app.config.RemoteConfig
import com.agenthita.sdk.detection.HarmCategory
import com.agenthita.sdk.detection.RiskLevel
import com.agenthita.app.telemetry.TelemetryManager
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import com.google.mediapipe.tasks.genai.llminference.LlmInferenceSession
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.atomic.AtomicBoolean
import java.util.zip.GZIPInputStream

/**
 * On-device Gemma classifier using MediaPipe LLM Inference API.
 *
 * Recommended model: Gemma 2B IT CPU INT4 (~900 MB, works on 4 GB RAM devices)
 *
 * Model setup:
 *   1. Download from Kaggle (select "TFLite" framework, "gemma-2b-it-cpu-int4" variation):
 *      https://www.kaggle.com/models/google/gemma3/frameworks/tfLite
 *   2. Push to the device:
 *      adb push gemma-2b-it-cpu-int4.bin /sdcard/Download/
 *   3. The classifier will auto-detect it and activate.
 *
 * Also accepts the heavier Gemma 2B models if already downloaded.
 *
 * Falls back to returning 0.0 (no boost) when the model is not present.
 * Rule-based detectors run fully in fallback mode — Gemma is additive.
 */
class GemmaClassifier(context: Context) {

    private var llm: LlmInference? = null
    val isLoaded: Boolean get() = llm != null

    /**
     * True when a model file was found on-device but MediaPipe failed to
     * initialise it (e.g. incompatible model format, insufficient RAM, corrupt file).
     * Stays false when the model was simply not installed — that is expected, not an error.
     */
    var loadFailed: Boolean = false
        private set

    // LlmInference is not thread-safe. Multiple accessibility events can trigger concurrent
    // coroutines on Dispatchers.IO; if two calls race on the native session the result is
    // a SIGSEGV (memcpy into a buffer being written by another thread). We use a non-blocking
    // trylock so that a concurrent caller skips inference rather than queuing behind it.
    private val inferenceInProgress = AtomicBoolean(false)

    // Single-entry cache — avoids re-running inference when the test pipeline calls
    // classifier.classify(text) immediately after scorer.score(text) with the same inputs.
    private var cacheKey: Triple<String, List<String>, String?> = Triple("", emptyList(), null)
    private var cacheVal: Pair<HarmCategory, RiskLevel>? = null

    init {
        tryLoad(context)
    }

    private fun tryLoad(context: Context) {
        // Remove any previously staged GPU models — they can't run on the CPU backend
        context.filesDir.listFiles()
            ?.filter { it.name.lowercase().contains("gpu") && (it.name.endsWith(".bin") || it.name.endsWith(".task")) }
            ?.forEach { f ->
                if (f.delete()) android.util.Log.i("GemmaClassifier", "Removed incompatible GPU model: ${f.name}")
            }

        // Remove undersized model files — they are interrupted/partial copies that will
        // pass the open-file check but crash MediaPipe's native parser on first inference.
        // Valid Gemma CPU INT4 models are ≥ 900 MB; 500 MB is a safe floor to catch truncations.
        context.filesDir.listFiles()
            ?.filter { f ->
                (f.name.endsWith(".bin") || f.name.endsWith(".task")) &&
                !f.name.lowercase().contains("gpu") &&
                f.length() < 500_000_000L
            }
            ?.forEach { f ->
                if (f.delete()) android.util.Log.w("GemmaClassifier", "Removed undersized model (likely partial copy): ${f.name}")
            }

        // 1. Try direct file access first (fast path)
        val modelPath = findModelPath(context)
            // 2. Fall back to copying model from MediaStore Downloads into internal storage.
            //    This handles Android 13+ scoped storage where the app's UID may differ from
            //    the POSIX owner of a previously-pushed model file in /sdcard/Download/.
            //    MediaStore tracks ownership by package name (not UID), so this survives reinstalls.
            ?: copyModelFromMediaStore(context)
            ?: run {
                android.util.Log.i("GemmaClassifier", "No model file found — running in rules-only mode")
                return
            }
        try {
            val options = LlmInference.LlmInferenceOptions.builder()
                .setModelPath(modelPath)
                .setMaxTokens(RemoteConfig.gemmaMaxTokens)
                .setPreferredBackend(LlmInference.Backend.CPU)
                .build()
            llm = LlmInference.createFromOptions(context, options)
            android.util.Log.i("GemmaClassifier", "Gemma loaded from $modelPath")
            TelemetryManager.get(context).track("gemma_load_success")
        } catch (e: Throwable) {
            loadFailed = true
            android.util.Log.w("GemmaClassifier", "Failed to load Gemma from $modelPath (${e.javaClass.simpleName}): ${e.message}")
            TelemetryManager.get(context).track("gemma_load_failed")
        }
    }

    /**
     * Queries MediaStore.Downloads for the model file by name and copies it to
     * [Context.filesDir] (internal storage, always readable by the app).
     *
     * MediaStore tracks Download ownership by package name rather than UID, so this
     * works even after an app uninstall/reinstall that changes the process UID.
     *
     * Returns the path of the staged copy, or null if the file is not in MediaStore.
     */
    private fun copyModelFromMediaStore(context: Context): String? {
        // Skip copy if already staged from a previous run.
        // Use 500 MB as the minimum — valid Gemma CPU INT4 models are ≥ 900 MB, so anything
        // smaller is a corrupted/partial copy that must not be reused.
        context.filesDir.listFiles()?.forEach { f ->
            if ((f.name.endsWith(".bin") || f.name.endsWith(".task")) && f.length() > 500_000_000L) {
                android.util.Log.i("GemmaClassifier", "Using pre-staged model: ${f.absolutePath}")
                return f.absolutePath
            }
        }

        // Query all large files in Downloads and match by extension — avoids hardcoded filenames
        // since Kaggle and browsers may download with arbitrary names (archive.tar.gz, etc.)
        val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
        val cursor = runCatching {
            context.contentResolver.query(
                collection,
                arrayOf(MediaStore.Downloads._ID, MediaStore.Downloads.DISPLAY_NAME, MediaStore.Downloads.SIZE),
                "${MediaStore.Downloads.SIZE} > ? AND ${MediaStore.Downloads.IS_PENDING} = 0",
                arrayOf("100000000"), null
            )
        }.getOrNull() ?: return null

        data class Entry(val id: Long, val name: String, val size: Long)
        val entries = cursor.use { c ->
            buildList {
                while (c.moveToNext()) {
                    add(Entry(c.getLong(0), c.getString(1) ?: continue, c.getLong(2)))
                }
            }
        }

        // Process .bin/.task first (no extraction needed), then .tar.gz
        val sorted = entries.sortedBy { if (it.name.lowercase().endsWith(".gz")) 1 else 0 }

        for (entry in sorted) {
            val lower = entry.name.lowercase()
            // .gz catches .tar.gz and Kaggle split names like .tar-1.gz
            val isTarGz = lower.endsWith(".gz")
            val isBinary = lower.endsWith(".bin") || lower.endsWith(".task")
            if (!isTarGz && !isBinary) continue
            // GPU-quantized models require OpenCL — skip them since we run CPU-only
            if (isBinary && lower.contains("gpu")) {
                android.util.Log.i("GemmaClassifier", "Skipping GPU model: ${entry.name}")
                continue
            }

            val fileUri = ContentUris.withAppendedId(collection, entry.id)

            if (isTarGz) {
                android.util.Log.i("GemmaClassifier", "Extracting ${entry.name} from MediaStore …")
                val extracted = runCatching {
                    context.contentResolver.openInputStream(fileUri)!!.use { extractTarGz(context, it) }
                }.getOrNull()
                if (extracted != null) return extracted
            } else {
                val dest = File(context.filesDir, entry.name)
                android.util.Log.i("GemmaClassifier", "Copying ${entry.name} from MediaStore → ${dest.absolutePath} …")
                val copied = runCatching {
                    context.contentResolver.openInputStream(fileUri)!!.use { input ->
                        FileOutputStream(dest).use { out -> input.copyTo(out, bufferSize = 8 * 1024 * 1024) }
                    }
                }.isSuccess
                // Verify the copy is complete by comparing byte-for-byte against the source size
                // from MediaStore. A partial copy (e.g. interrupted transfer) would pass a simple
                // > 100 MB check but crash MediaPipe's native parser on first inference (SIGSEGV
                // in LlmInferenceEngine_CreateSession via resetImplicitSession).
                if (copied && dest.length() == entry.size) {
                    android.util.Log.i("GemmaClassifier", "Copy complete: ${dest.length() / 1_000_000} MB")
                    // Remove from Downloads — model is now in private app storage where
                    // the user can't accidentally delete it. Best-effort: if the entry is
                    // not owned by this app (e.g. pushed via adb), MediaStore delete will
                    // throw RecoverableSecurityException — we log and continue.
                    runCatching { context.contentResolver.delete(fileUri, null, null) }
                        .onSuccess { android.util.Log.i("GemmaClassifier", "Downloads copy removed — model in app storage") }
                        .onFailure { android.util.Log.w("GemmaClassifier", "Could not remove Downloads copy: ${it.message}") }
                    return dest.absolutePath
                } else {
                    dest.delete()
                }
            }
        }
        return null
    }

    /**
     * Verifies the extracted model file against the SHA-256 allow-list in RemoteConfig.
     * Returns true when the list is empty (check not yet configured) or when the file's
     * digest matches an entry. Returns false — and the caller must delete the file — when
     * hashes are configured and none match, indicating a potentially malicious file.
     */
    private fun verifyModelFile(context: Context, file: File): Boolean =
        Companion.verifyModelFile(context, file)

    private fun extractTarGz(context: Context, inputStream: java.io.InputStream): String? =
        Companion.extractTarGz(context, inputStream)

    companion object {

    /**
     * Builds a prompt guaranteed to fit the model's token window. Never skips:
     * long conversations lose their OLDEST content first — context lines are shed
     * one at a time, then the message block is trimmed from the front — because
     * coercion escalates toward the end of a window ("send money now" is at the
     * recent edge; the opener is what we can afford to lose).
     */
    internal fun buildFittedPrompt(text: String, context: List<String>, ageHint: String?): String {
        // ~3 chars/token heuristic; reserve 50 tokens of the window for the response.
        val maxChars = (RemoteConfig.gemmaMaxTokens - 50) * 3
        var ctx = context
        var prompt = buildMultiClassPrompt(text, ctx, ageHint)
        while (prompt.length > maxChars && ctx.isNotEmpty()) {
            ctx = ctx.drop(1)
            prompt = buildMultiClassPrompt(text, ctx, ageHint)
        }
        if (prompt.length > maxChars) {
            val overhead = buildMultiClassPrompt("", ctx, ageHint).length
            val budget = (maxChars - overhead).coerceAtLeast(160)
            prompt = buildMultiClassPrompt(keepNewest(text, budget), ctx, ageHint)
        }
        if (prompt.length < buildMultiClassPrompt(text, context, ageHint).length) {
            android.util.Log.i("GemmaClassifier", "Prompt trimmed to fit (~${prompt.length / 3} tokens)")
        }
        return prompt
    }

    /** Last [budget] chars of [text], dropped forward to the next full line where possible. */
    internal fun keepNewest(text: String, budget: Int): String {
        if (text.length <= budget) return text
        val tail = text.takeLast(budget)
        val nl = tail.indexOf('\n')
        return if (nl in 0 until tail.length - 40) tail.substring(nl + 1) else tail
    }

    internal fun buildMultiClassPrompt(text: String, context: List<String> = emptyList(), ageHint: String? = null): String {
        // ONE template for every model. This is the June-era wording that both the
        // 2B and the gemma3-1b demonstrably worked with, plus exactly one extension
        // ("or bank transaction alerts") carrying the UPI-notification decision.
        //
        // The completion-style 2B is exquisitely sensitive to this wording: the
        // gemma3-tuned rewrite of 2026-07-18 made it echo the prompt instead of
        // answering (a live sextortion test scored NONE because the model returned
        // our own multilingual instruction line as its "answer", 2026-07-19).
        // Do not reword without re-running the on-device probe set — false-positive
        // texts AND the canonical attack scripts — on every supported model.
        //
        // Total prompt must stay under gemmaMaxTokens (default 512). The fixed
        // template is ~670 chars (~190 tokens); buildFittedPrompt enforces the hard
        // limit before inference, keeping the newest content when trimming.
        val truncated = keepNewest(text, RemoteConfig.gemmaInputTruncationChars)
        val recipientLine = if (ageHint != null) "\nRecipient: $ageHint" else ""
        val contextBlock = if (context.isEmpty()) "" else {
            val prior = context.takeLast(3).joinToString("\n") { "- \"${it.take(60)}\"" }
            "\nPrior messages in conversation:\n$prior"
        }
        return """Identify the harm in this message. Fill in the blanks below.

Valid harm types: SEXTORTION FINANCIAL_SCAM GROOMING ROMANCE_SCAM IDENTITY_PHISHING LURING HARASSMENT NONE
Valid severity levels: HIGH MEDIUM LOW NONE
Messages: [CONTACT]=incoming, [USER]=outgoing. The threat actor is [CONTACT]; [USER] messages showing distress, compliance, or fear are evidence of harm, not its source. For HARASSMENT, flag threats or abuse in either direction.
IDENTITY_PHISHING: [CONTACT] requesting credentials or info, or [USER] sending an OTP to the contact = HIGH. Automated OTP delivery or bank transaction alerts to the user = NONE. For child/adolescent recipients, [USER] sharing an address or location = GROOMING or LURING; only a phone number = NONE. Other [USER] self-shared info = NONE.
IMPORTANT: Messages may mix English with other languages written in Latin letters (e.g. romanised Hindi, Urdu, Turkish). Ignore any non-English words and analyse only the English words present. If there are no English words, respond with Harm type: NONE and Severity: NONE.
Casual slang alone isn't harm — flag only real threats, coercion, or money/image/credential requests.
$recipientLine$contextBlock
Latest message: "$truncated"

Harm type:
Severity: """.trimIndent()
    }

        /**
         * Shared entry point used by both the service (auto-detection) and
         * GemmaDownloadActivity (user-selected file import).
         */
        internal fun extractTarGz(context: Context, inputStream: java.io.InputStream): String? {
            return extractTarGzImpl(context, inputStream)
        }

        private fun verifyModelFile(context: Context, file: File): Boolean {
        val allowedHashes = RemoteConfig.gemmaModelHashes
        if (allowedHashes.isEmpty()) {
            android.util.Log.e("GemmaClassifier", "gemmaModelHashes is empty — model loaded without integrity check. Populate via remote config.")
            TelemetryManager.get(context).track("gemma_hash_verification_skipped")
            return true
        }

        return try {
            val digest = java.security.MessageDigest.getInstance("SHA-256")
            val buf = ByteArray(8 * 1024 * 1024)
            file.inputStream().use { input ->
                var n: Int
                while (input.read(buf).also { n = it } != -1) digest.update(buf, 0, n)
            }
            val hex = digest.digest().joinToString("") { "%02x".format(it) }
            android.util.Log.i("GemmaClassifier", "Model SHA-256: $hex")
            (hex in allowedHashes).also { match ->
                if (!match) android.util.Log.w("GemmaClassifier", "SHA-256 not in allow-list")
            }
        } catch (e: Exception) {
            android.util.Log.w("GemmaClassifier", "Hash verification error: ${e.message}")
            false  // Fail closed — can't verify, reject
        }
    }

        private fun extractTarGzImpl(context: Context, inputStream: java.io.InputStream): String? {
        val headerBuf = ByteArray(512)
        val ioBuf = ByteArray(8 * 1024 * 1024)

        fun readFully(stream: java.io.InputStream, buf: ByteArray, len: Int = buf.size): Boolean {
            var pos = 0
            while (pos < len) {
                val n = stream.read(buf, pos, len - pos)
                if (n < 0) return false
                pos += n
            }
            return true
        }

        fun skipFully(stream: java.io.InputStream, bytes: Long): Boolean {
            var rem = bytes
            while (rem > 0) {
                val n = stream.read(ioBuf, 0, minOf(rem, ioBuf.size.toLong()).toInt())
                if (n < 0) return false
                rem -= n
            }
            return true
        }

        try {
            GZIPInputStream(inputStream, 8 * 1024 * 1024).use { gz ->
                while (true) {
                    if (!readFully(gz, headerBuf)) return null
                    // Two consecutive zero blocks = end of archive
                    if (headerBuf.all { it == 0.toByte() }) return null

                    val entryName  = String(headerBuf, 0, 100, Charsets.UTF_8).trimEnd('\u0000')
                    val sizeOctal  = String(headerBuf, 124, 12, Charsets.UTF_8).trimEnd('\u0000').trim()
                    val typeFlag   = headerBuf[156].toInt().toChar()
                    val fileSize   = if (sizeOctal.isEmpty()) 0L else sizeOctal.toLong(8)
                    val paddedSize = ((fileSize + 511) / 512) * 512

                    val baseName   = entryName.substringAfterLast('/')
                    val isRegular  = typeFlag == '0' || typeFlag == '\u0000'
                    // 500 MB floor rejects garbage; configurable ceiling prevents storage exhaustion
                    // from a crafted TAR header declaring a huge file size (real models are ~1-4 GB).
                    val isSane     = fileSize in 500_000_000L..RemoteConfig.gemmaMaxFileSizeBytes
                    val isModel    = isRegular && isSane &&
                        (baseName.endsWith(".bin") || baseName.endsWith(".task")) &&
                        !baseName.lowercase().contains("gpu")

                    if (isModel) {
                        val dest = File(context.filesDir, baseName)
                        android.util.Log.i("GemmaClassifier", "Extracting $entryName → ${dest.absolutePath}")
                        val ok = runCatching {
                            FileOutputStream(dest).use { out ->
                                var rem = fileSize
                                while (rem > 0) {
                                    val n = gz.read(ioBuf, 0, minOf(rem, ioBuf.size.toLong()).toInt())
                                    if (n < 0) error("Unexpected EOF during extraction")
                                    out.write(ioBuf, 0, n)
                                    rem -= n
                                }
                            }
                            val pad = paddedSize - fileSize
                            if (pad > 0) skipFully(gz, pad)
                        }.isSuccess
                        if (ok && dest.length() == fileSize) {
                            if (!verifyModelFile(context, dest)) {
                                android.util.Log.w("GemmaClassifier", "Hash mismatch — rejecting $baseName")
                                TelemetryManager.get(context).track("gemma_hash_mismatch")
                                dest.delete()
                                return null
                            }
                            android.util.Log.i("GemmaClassifier", "Extraction complete: ${dest.length() / 1_000_000} MB")
                            return dest.absolutePath
                        }
                        dest.delete()
                        return null
                    }

                    if (!skipFully(gz, paddedSize)) return null
                }
            }
        } catch (e: Exception) {
            android.util.Log.w("GemmaClassifier", "TAR extraction error: ${e.message}")
        }
        return null
        }
        private val CATEGORY_TOKENS = mapOf(
            "SEXTORTION"        to HarmCategory.SEXTORTION,
            "FINANCIAL_SCAM"    to HarmCategory.FINANCIAL_SCAM,
            "GROOMING"          to HarmCategory.GROOMING,
            "ROMANCE_SCAM"      to HarmCategory.ROMANCE_SCAM,
            "ROMANCE"           to HarmCategory.ROMANCE_SCAM,
            "IDENTITY_PHISHING" to HarmCategory.IDENTITY_PHISHING,
            "PHISHING"          to HarmCategory.IDENTITY_PHISHING,
            "LURING"            to HarmCategory.LURING,
            "HARASSMENT"        to HarmCategory.HARASSMENT
        )

        /**
         * Token-scanning parser — does NOT rely on Gemma following a strict format.
         * Expects the UPPERCASED response (the call site uppercases before parsing).
         *
         * Gemma produces inconsistent responses:
         *   "SEXTORTION HIGH"           → ideal
         *   "IDENTITY_PHISHING"         → category only (default to MEDIUM)
         *   "Harm type: GROOMING\nSeverity: HIGH" → fill-in format (handled)
         *   "CATEGORY SEVERITY: HIGH"   → echoed template (no valid category)
         *   "SCAMMING"                  → invented word (no match)
         *
         * Strategy: strip non-alphanumeric chars, tokenise, anchor after the last
         * "HARM TYPE" / "SEVERITY" labels, then scan for the FIRST verdict token —
         * where an explicit NONE terminates the scan. NONE must not be skipped:
         * a rambling safe answer like "NONE. THIS IS A BANK ALERT, NOT PHISHING."
         * previously parsed as IDENTITY_PHISHING (the trailing "PHISHING" token),
         * and "NONE (NOT HIGH RISK)" as severity HIGH — manufacturing alerts out
         * of safe verdicts.
         */
        internal fun parseMultiClassResponse(response: String): Pair<HarmCategory, RiskLevel>? {
            // Strip colons, slashes, punctuation — keep letters, digits, underscores
            val normalized = response.replace(Regex("[^A-Z0-9_\\s]"), " ")
            val tokens = normalized.split(Regex("\\s+")).filter { it.isNotBlank() }

            // Anchor to the last "HARM TYPE" label pair in the token list. When Gemma echoes
            // the prompt back verbatim it repeats the valid-harm-types list (which contains
            // "SEXTORTION", "GROOMING" etc.) before printing the actual fill-in answer. Scanning
            // from the last "HARM TYPE" label means we read Gemma's answer, not the echoed list.
            val harmTypeIdx = (tokens.indices).lastOrNull { i ->
                tokens[i] == "HARM" && tokens.getOrNull(i + 1) == "TYPE"
            }?.plus(2) ?: 0

            val categoryToken = tokens.drop(harmTypeIdx)
                .firstOrNull { it == "NONE" || it in CATEGORY_TOKENS }
            val category = when (categoryToken) {
                null, "NONE" -> return null  // explicit NONE or unparseable → safe
                else         -> CATEGORY_TOKENS.getValue(categoryToken)
            }

            // Anchor severity search after the last "SEVERITY" label token similarly.
            val severityIdx = (tokens.indices).lastOrNull { i ->
                tokens[i] == "SEVERITY"
            }?.plus(1) ?: 0

            val severityToken = tokens.drop(severityIdx)
                .firstOrNull { it in setOf("HIGH", "MEDIUM", "LOW", "NONE") }
            val severity = when (severityToken) {
                "HIGH"   -> RiskLevel.HIGH
                "MEDIUM" -> RiskLevel.MEDIUM
                "LOW"    -> RiskLevel.LOW
                "NONE"   -> return null      // explicit no-severity verdict → safe
                else     -> RiskLevel.MEDIUM // category found, severity omitted
            }

            return Pair(category, severity)
        }
    }  // end companion object

    private fun findModelPath(context: Context): String? {
        // Fast path: model already in private app storage from a previous run.
        // Scan by extension + size so any model filename is accepted (not just gemma.bin).
        context.filesDir.listFiles()?.firstOrNull { f ->
            (f.name.endsWith(".bin") || f.name.endsWith(".task")) &&
            !f.name.lowercase().contains("gpu") &&
            f.length() > 500_000_000L &&
            try { java.io.FileInputStream(f).use { true } } catch (_: Exception) { false }
        }?.let {
            android.util.Log.i("GemmaClassifier", "Model found: ${it.absolutePath}")
            return it.absolutePath
        }

        val appFiles = context.getExternalFilesDir(null)?.absolutePath
        val candidates = listOf(
            // App-private external storage — readable when external storage is mounted
            "$appFiles/gemma.task",
            "$appFiles/gemma.bin",
            // Downloads — CPU variants only; GPU models require OpenCL which we don't use
            "/sdcard/Download/gemma-2b-it-cpu-int4.task",
            "/storage/emulated/0/Download/gemma-2b-it-cpu-int4.task",
            "/sdcard/Download/gemma-2b-it-cpu-int4.bin",
            "/sdcard/Download/gemma-2b-it-cpu-int4.bin",
            "/sdcard/Download/gemma2-cpu-int4.bin",
            "/sdcard/Download/gemma.task",
            "/storage/emulated/0/Download/gemma.task",
            "/sdcard/Download/gemma.bin"
        )
        // Use FileInputStream to probe actual read access — canRead() can return false on
        // Android 13+ for files in Downloads even when POSIX permissions allow access,
        // due to how scoped storage interacts with the security model.
        val binary = candidates.firstOrNull { path ->
            try { java.io.FileInputStream(path).use { true } } catch (_: Exception) { false }
        }
        if (binary != null) {
            android.util.Log.i("GemmaClassifier", "Model found: $binary")
            return binary
        }

        // Try extracting from any .gz archive in Downloads (Kaggle uses names like
        // gemma3-keras-gemma3_instruct_1b-v3.tar-1.gz — match by extension, not filename)
        for (dir in listOf("/sdcard/Download", "/storage/emulated/0/Download")) {
            val files = runCatching { java.io.File(dir).listFiles() }.getOrNull() ?: continue
            for (f in files.sortedBy { it.name }) {
                if (!f.name.lowercase().endsWith(".gz")) continue
                val extracted = try {
                    java.io.FileInputStream(f).use { extractTarGz(context, it) }
                } catch (_: Exception) { null }
                if (extracted != null) {
                    android.util.Log.i("GemmaClassifier", "Model extracted from archive: ${f.absolutePath}")
                    // Delete the archive from Downloads — model is now in private app storage
                    if (f.delete()) {
                        android.util.Log.i("GemmaClassifier", "Archive removed from Downloads")
                    } else {
                        android.util.Log.w("GemmaClassifier", "Could not remove archive from Downloads (scoped storage)")
                    }
                    return extracted
                }
            }
        }

        android.util.Log.i("GemmaClassifier", "No model found in any candidate path")
        return null
    }

    /**
     * Single multi-class inference: Gemma identifies the most likely harm category
     * and severity in one LLM call. This replaces the old per-category getBoost()
     * approach so that Gemma can detect harm categories that rules miss entirely.
     *
     * Returns null if the model is not loaded, the message is safe, or the
     * response cannot be parsed.
     */
    fun classifyMessage(text: String, context: List<String> = emptyList(), ageHint: String? = null): Pair<HarmCategory, RiskLevel>? {
        val inference = llm ?: return null
        val key = Triple(text, context, ageHint)
        if (key == cacheKey) {
            android.util.Log.d("GemmaClassifier", "Cache hit — skipping inference")
            return cacheVal
        }
        return try {
            val prompt = buildFittedPrompt(text, context, ageHint)
            if (!inferenceInProgress.compareAndSet(false, true)) {
                android.util.Log.d("GemmaClassifier", "Inference already in progress, skipping concurrent call")
                return null
            }
            try {
                val t0 = System.currentTimeMillis()
                // Constrained sampling for classification: default sampling (topK 40,
                // temp ~0.8) lets the completion drift into prose — observed live on
                // the 2B (2026-07-19), which described the harm in free text but never
                // emitted the "Harm type:/Severity:" tokens, so real attacks parsed as
                // NONE. Low temperature + tiny topK pin the most likely continuation:
                // filling in the form. Values are OTA-tunable (gemma.top_k /
                // gemma.temperature). generateAnalysis keeps default sampling — prose
                // is desirable there.
                val sessionOptions = LlmInferenceSession.LlmInferenceSessionOptions.builder()
                    .setTopK(RemoteConfig.gemmaTopK)
                    .setTemperature(RemoteConfig.gemmaTemperature)
                    .build()
                val session = LlmInferenceSession.createFromOptions(inference, sessionOptions)
                val response = try {
                    session.addQueryChunk(prompt)
                    session.generateResponse().trim().uppercase()
                } finally {
                    session.close()
                }
                val ms = System.currentTimeMillis() - t0
                android.util.Log.i("GemmaClassifier", "Inference took ${ms}ms | response: \"$response\"")
                parseMultiClassResponse(response).also {
                    cacheKey = key
                    cacheVal = it
                }
            } finally {
                inferenceInProgress.set(false)
            }
        } catch (e: Exception) {
            android.util.Log.w("GemmaClassifier", "Multi-class inference error: ${e.message}")
            null
        }
    }



    /**
     * Generates a short human-readable analysis and safety recommendations for the alert detail view.
     * Returns null if Gemma is not loaded or inference fails.
     */
    fun generateAnalysis(
        lastMessage: String,
        context: List<String>,
        signals: List<String>,
        category: HarmCategory
    ): String? {
        val inference = llm ?: return null
        if (!inferenceInProgress.compareAndSet(false, true)) {
            android.util.Log.d("GemmaClassifier", "Inference busy, skipping analysis")
            return null
        }
        return try {
            val prompt = buildAnalysisPrompt(lastMessage, context, signals, category)
            val response = inference.generateResponse(prompt).trim()
            android.util.Log.d("GemmaClassifier", "Analysis generated (${response.length} chars)")
            response.ifBlank { null }
        } catch (e: Exception) {
            android.util.Log.w("GemmaClassifier", "Analysis inference error: ${e.message}")
            null
        } finally {
            inferenceInProgress.set(false)
        }
    }

    private fun buildAnalysisPrompt(
        lastMessage: String,
        context: List<String>,
        signals: List<String>,
        category: HarmCategory
    ): String {
        val categoryLabel = when (category) {
            HarmCategory.SEXTORTION        -> "sexual manipulation / sextortion"
            HarmCategory.FINANCIAL_SCAM    -> "financial scam"
            HarmCategory.GROOMING          -> "predatory grooming"
            HarmCategory.ROMANCE_SCAM      -> "romance scam"
            HarmCategory.IDENTITY_PHISHING -> "identity phishing"
            HarmCategory.LURING            -> "luring via fake offer"
            HarmCategory.HARASSMENT             -> "harassment or threats"
            HarmCategory.DISAPPEARING_MESSAGES  -> "disappearing messages / secrecy signal"
            // iOS-keyboard-only categories for now — Android's own detectors
            // don't produce these yet, so this is just exhaustiveness.
            else -> "a safety concern"
        }
        val signalList = signals.take(5).joinToString(", ").ifEmpty { "none" }

        // Budget ~280 tokens for conversation text (512 total - ~80 prompt overhead - ~150 response)
        val ctxMessages = RemoteConfig.gemmaContextMessages
        val ctxMsgLen   = RemoteConfig.gemmaContextMessageLength
        val conversationBlock = if (context.isEmpty()) {
            "Message: \"$lastMessage\""
        } else {
            val trimmedContext = context.takeLast(ctxMessages).joinToString("\n") { "- \"${it.take(ctxMsgLen)}\"" }
            "Previous messages:\n$trimmedContext\n\nLatest message: \"${lastMessage.take(ctxMsgLen)}\""
        }

        return """You are a safety advisor helping someone who received a concerning message.
Category: $categoryLabel
Signals: $signalList
$conversationBlock

In 2-3 sentences, explain why this conversation is concerning. Then give exactly 2 safety tips starting with "Tip 1:" and "Tip 2:". Be clear and supportive.
IMPORTANT: Do NOT advise contacting, responding to, or engaging further with the sender. Do NOT suggest meeting or replying to them. Tips must focus on blocking, reporting, and seeking help.""".trimIndent()
    }

    fun close() {
        llm?.close()
        llm = null
    }
}

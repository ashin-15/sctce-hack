package com.agenthita.app.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Rect
import android.os.Build
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.agenthita.app.BuildConfig
import com.agenthita.app.HitaApplication
import com.agenthita.app.alert.GuardianAlertSender
import com.agenthita.app.config.RemoteConfig
import com.agenthita.app.alert.LocalNotificationManager
import com.agenthita.app.consent.AntiCoercionMonitor
import com.agenthita.app.consent.ConsentManager
import com.agenthita.sdk.detection.RiskLevel
import com.agenthita.sdk.detection.RiskScorer
import com.agenthita.app.model.OnDeviceClassifier
import com.agenthita.app.storage.ContactNameDao
import com.agenthita.app.storage.ContactNameEntry
import com.agenthita.app.storage.RiskEventStore
import com.agenthita.app.telemetry.TelemetryManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.security.MessageDigest

/**
 * Reads message content from the screen when the user opens a 1-1 conversation
 * in WhatsApp, Instagram DM, or SMS. Uses AccessibilityService to traverse the
 * active window's view hierarchy — no notification required, works even when
 * the app is in the foreground.
 *
 * Privacy: message text is analysed in-memory only. Nothing is written to disk
 * except the scored RiskEvent (category, risk level, score, signal types — no
 * raw message text).
 *
 * Group chats are deliberately ignored: a conversation is only analysed if it
 * cannot be identified as a group (checked via subtitle / member count signals
 * in the view hierarchy).
 */
class HitaAccessibilityService : AccessibilityService() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mainHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val pendingRunnables = mutableMapOf<String, Runnable>()

    private lateinit var classifier: com.agenthita.app.model.OnDeviceClassifier
    private lateinit var riskScorer: RiskScorer
    private lateinit var localNotificationManager: LocalNotificationManager
    private lateinit var guardianAlertSender: GuardianAlertSender
    private lateinit var riskEventStore: RiskEventStore
    private lateinit var consentManager: ConsentManager
    private lateinit var antiCoercionMonitor: AntiCoercionMonitor
    private lateinit var contactNameDao: ContactNameDao

    private lateinit var dedupPrefs: android.content.SharedPreferences
    private lateinit var seenTracker: SeenMessageTracker

    // Independent heartbeat timer — writes every 60s regardless of accessibility events.
    // This prevents false "frozen" alerts when the device is idle (no monitored apps open).
    // If Samsung freezes the process, the main thread suspends and the timer stops,
    // which correctly causes the heartbeat to go stale and triggers the frozen warning.
    private val heartbeatRunnable: Runnable = object : Runnable {
        override fun run() {
            writeHeartbeat()
            // pingIfDue no-ops instantly unless a day has actually rolled over, so
            // checking on every 60s tick is cheap — this is what lets the backend
            // count devices actively being protected, not just ever-registered.
            serviceScope.launch { com.agenthita.app.security.DeviceTokenManager.pingIfDue(this@HitaAccessibilityService) }
            mainHandler.postDelayed(this, HEARTBEAT_INTERVAL_MS)
        }
    }

    companion object {
        const val ACTION_MODEL_AVAILABLE = "com.agenthita.app.MODEL_AVAILABLE"
        private const val TAG                = "HitaAccessibilityService"
        private const val TAG_IG_DIAG        = "HitaIG"
        internal const val MIN_MESSAGE_LENGTH = 8
        private const val MAX_UNRECOGNIZED_VIEW_IDS_PER_EVENT = 10

        /**
         * Subtitle-based group identification for WhatsApp. Group subtitles show
         * the participant list ("Alice, Bob, You"), "N members", "Community",
         * "Channel", "N online", or the placeholder "tap here for group info".
         * 1-1 chats show presence ("online", "last seen …") or "tap here for
         * contact info" — none of which match.
         */
        internal fun isWhatsAppGroupSubtitle(subtitle: String): Boolean =
            subtitle.contains("member", ignoreCase = true) ||
            subtitle.contains("community", ignoreCase = true) ||
            subtitle.contains("channel", ignoreCase = true) ||
            subtitle.contains("group info", ignoreCase = true) ||
            subtitle.split(",").size >= 2 ||
            subtitle.matches(Regex("\\d+\\s+online.*", RegexOption.IGNORE_CASE))
        private const val DEDUP_PREFS        = "hita_dedup"
        // Threshold imported from DisappearingMessageUtils — kept as alias here for log messages.
        private val SHORT_TIMER_THRESHOLD_DAYS = com.agenthita.sdk.detection.DISAPPEARING_SHORT_TIMER_THRESHOLD_DAYS
        private const val AI_PREFS           = "hita_ai_prefs"
        private const val KEY_GEMMA_LOADED       = "gemma_loaded"
        private const val KEY_GEMMA_FAILED       = "gemma_load_failed"
        private const val KEY_SERVICE_LAST_ALIVE = "service_last_alive_ms"
        private const val HEARTBEAT_INTERVAL_MS  = 60_000L
        const val NOTIFICATION_ID_STATUS         = 1000
        private const val DEDUP_MAX_ENTRIES  = 500
        // Bounds how much prior on-screen history is fed into scoring as context.
        // Gemma's own prompt only ever renders the last 3 of whatever it's given
        // (buildMultiClassPrompt), so this doesn't change what the model sees —
        // it bounds the rule-based context-escalation pass and the classifier's
        // prompt-fitting work, both of which otherwise scale with however many
        // messages happen to be visible on screen (unbounded on a long scroll-back).
        private const val MAX_SEEN_MESSAGES_FOR_CONTEXT = 10
        private const val CONV_KEY_PREFIX         = "last_"
        private const val SEEN_KEY_PREFIX         = "seen_"
        private const val DISAPPEARING_KEY_PREFIX = "disappearing_"

        // Media-only messages that carry no conversational text and should be ignored.
        // Handles bare labels ("Video"), metadata suffixes ("Video · 0:21", "Voice message (5.4 MB)"),
        // and leading emoji ("🎥 Video"). The suffix anchor [·•()\d] prevents natural-language
        // captions like "Video of us at the party" from being filtered — only suffixes that start
        // with a bullet, parenthesis, or digit are treated as media metadata.
        internal val MEDIA_LABEL_PATTERN = Regex(
            """^[^a-zA-Z]*(photo|image|video|gif|sticker|audio|voice\s*message|document|contact|location|file)(\s*[·•()\d].*)?$""",
            RegexOption.IGNORE_CASE
        )
        internal val MEDIA_FILE_EXTENSION = Regex(
            """.*\.(jpg|jpeg|png|gif|webp|heic|heif|bmp|tiff?|svg|mp4|mov|avi|mkv|mp3|aac|ogg|m4a|pdf|doc|docx|xls|xlsx|ppt|pptx)$""",
            RegexOption.IGNORE_CASE
        )

        // Conversation date separators rendered as plain TextViews ("December 4, 2025",
        // "4 Dec 2025", "Wednesday"). Matched whole-line only, so a real message that
        // merely mentions a month or day is untouched. Voice-message-only chats have no
        // message_text nodes, and the structural fallback walk otherwise scrapes these
        // separators as "messages" (seen live 2026-07-18: "December 4, 2025" was scored
        // and Gemma hallucinated GROOMING on it).
        private const val MONTHS =
            "jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|" +
            "jul(?:y)?|aug(?:ust)?|sept?(?:ember)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?"
        internal val DATE_SEPARATOR_PATTERN = Regex(
            "(?:monday|tuesday|wednesday|thursday|friday|saturday|sunday)" +
            "|(?:$MONTHS)\\s+\\d{1,2}(?:,\\s*\\d{4})?" +
            "|\\d{1,2}\\s+(?:$MONTHS)(?:\\s+\\d{4})?",
            RegexOption.IGNORE_CASE
        )

        // Call-log rows and in-call chrome ("Voice call", "Missed voice call",
        // "Missed voice call - Tap to call back", "Video call · 2:34",
        // "Tap to call back", "Tap to return to call"). During the transient
        // 0-node windows around a call the structural fallback walks the call UI,
        // so these must be filtered or they get scored as messages. Suffixes must
        // start with a non-letter so a real message like "voice call me tomorrow"
        // is never filtered.
        internal val CALL_CHROME_PATTERN = Regex(
            "(?:missed\\s+|ongoing\\s+|incoming\\s+|outgoing\\s+)?(?:voice|video)\\s+call(?:\\s*[·•,(\\d\\-–—].*)?" +
            "|(?:tap\\s+to\\s+)?call\\s+(?:back|again|ended)|no\\s+answer|tap\\s+to\\s+return\\s+to\\s+call.*",
            RegexOption.IGNORE_CASE
        )

        /**
         * True when a node's view ID marks it as conversation chrome that must
         * never be treated as a message by the structural fallback walk —
         * text-pattern filters cannot catch these because they carry arbitrary
         * content (e.g. WhatsApp's out_of_chat_title renders another contact's
         * NAME when a message from a different chat pops up over the open
         * conversation; scored live as IDENTITY_PHISHING on 2026-07-18).
         * Matches on the bare ID (after "id/") so package qualification and
         * app differences don't matter.
         */
        internal fun isFallbackChromeId(viewIdResourceName: String?, excludedPrefixes: List<String>): Boolean {
            val bareId = viewIdResourceName?.substringAfterLast("/") ?: return false
            return excludedPrefixes.any { bareId.startsWith(it) }
        }

        /**
         * True if [bareId] (already stripped of any package/"id/" prefix) is NOT covered by
         * [knownExact] (exact-match known view IDs) or [knownPrefixes] (prefix-match known
         * chrome, e.g. WhatsApp's waFallbackExcludedIdPrefixes) — i.e. it's a genuinely
         * unrecognized element worth surfacing as a parsing-failure diagnostic signal.
         */
        internal fun isUnrecognizedViewId(bareId: String, knownExact: Set<String>, knownPrefixes: List<String>): Boolean =
            bareId !in knownExact && knownPrefixes.none { bareId.startsWith(it) }

        /**
         * Known-good view IDs for [packageName]'s message-extraction paths — used to tell
         * apart "an element we already understand" from "something new/unexpected" when
         * collecting unrecognized-view-ID diagnostics on a parsing failure. Returns
         * (exact-match set, prefix-match list).
         */
        internal fun knownViewIdsFor(packageName: String): Pair<Set<String>, List<String>> {
            val t = RemoteConfig.uiTags
            val knownExact: Set<String> = when (packageName) {
                "com.whatsapp", "com.whatsapp.w4b" -> (setOf(
                    t.waMessageTextId, t.waContactNameId, t.waContactStatusId,
                    t.waGroupSenderNameId, t.waEntryId, t.waSendId, t.waStatusId, t.waEditBarId
                ) + t.waMessageContentIds)
                "com.instagram.android" -> (setOf(
                    t.igComposerEditTextId, t.igSendButtonId, t.igDirectSendButtonId,
                    t.igRecyclerViewId, t.igHeaderTitleId, t.igHeaderSubtitleId, t.igEditBarId
                ) + t.igMessageTextIds)
                else -> emptySet()
            }.filterTo(mutableSetOf()) { it.isNotBlank() }
            val knownPrefixes: List<String> =
                if (packageName == "com.whatsapp" || packageName == "com.whatsapp.w4b") t.waFallbackExcludedIdPrefixes
                else emptyList()
            return knownExact to knownPrefixes
        }

        internal fun isUIChrome(text: String, minLength: Int, gmUiChromePrefixes: List<String>): Boolean {
            if (text.length < minLength) return true
            val lower = text.lowercase().trim()
            if (lower == "send" || lower == "type a message" || lower == "message") return true
            if (lower.startsWith("today") || lower.startsWith("yesterday")) return true
            // Conversation-header chrome (walked by the structural fallback).
            if (lower.startsWith("last seen") || lower.startsWith("tap here for")) return true
            if (lower.matches(Regex("\\d{1,2}:\\d{2}\\s*(am|pm)?", RegexOption.IGNORE_CASE))) return true
            if (DATE_SEPARATOR_PATTERN.matches(lower)) return true
            if (CALL_CHROME_PATTERN.matches(lower)) return true
            if (gmUiChromePrefixes.any { lower.startsWith(it) }) return true
            return false
        }

        internal fun isMediaMessage(text: String): Boolean {
            val trimmed = text.trim()
            return MEDIA_LABEL_PATTERN.matches(trimmed) || MEDIA_FILE_EXTENSION.matches(trimmed)
        }

        /**
         * Compiles a config-provided regex-source list on demand, re-compiling only
         * when the OTA config replaces the list. Invalid patterns are skipped so a
         * bad OTA entry can never crash the scan.
         */
        internal class RegexListCache(private val source: () -> List<String>) {
            private var cachedSource: List<String>? = null
            private var compiled: List<Regex> = emptyList()
            fun get(): List<Regex> {
                val src = source()
                if (src !== cachedSource) {
                    compiled = src.mapNotNull { runCatching { Regex(it) }.getOrNull() }
                    cachedSource = src
                }
                return compiled
            }
        }

        // Disappearing-messages banner patterns come from RemoteConfig (OTA-updatable —
        // messenger apps reword these banners between releases). A node alerts only if
        // an ON pattern matches and no OFF pattern and no instructional-HINT pattern
        // matches the same text (e.g. Instagram's "swipe up to turn on disappearing
        // messages" promo must never alert).
        private val disappearingOn   = RegexListCache { RemoteConfig.uiTags.disappearingOnPatterns }
        private val disappearingOff  = RegexListCache { RemoteConfig.uiTags.disappearingOffPatterns }
        private val disappearingHint = RegexListCache { RemoteConfig.uiTags.disappearingHintPatterns }

        internal fun isDisappearingActivationText(text: String): Boolean =
            disappearingOn.get().any { it.containsMatchIn(text) } &&
            disappearingOff.get().none { it.containsMatchIn(text) } &&
            disappearingHint.get().none { it.containsMatchIn(text) }
    }

    // Conversations where disappearing messages were seen but suppressed (long default timer,
    // no active threat). Cleared on conversation exit so if a threat develops in a later
    // session we re-evaluate. Not persisted — the persistent dedup key is only set when we
    // actually fire, so a suppressed conv can be upgraded to MEDIUM if a threat is later found.
    private val disappearingMessagesSuppressed = mutableSetOf<String>()

    // Conversations that already reported an empty-extraction telemetry event this
    // session — one signal per conversation visit is enough for dashboard trends.
    private val extractionEmptyTracked = mutableSetOf<String>()

    // Packages that already reported a contact-name-extraction failure or parsing
    // exception during the current conversation-screen visit. Keyed by package, not
    // convHash, because both failures happen before the contact name (and therefore
    // convHash) is known. Without this, a single broken screen re-reports on every
    // TYPE_WINDOW_CONTENT_CHANGED event (~every 1.5s) for as long as the user stays on
    // it — WhatsApp alone fires those constantly via read receipts and timestamp ticks,
    // which is what inflated the parsing-failure counts on the dashboard.
    private val parsingFailureTrackedPackages = mutableSetOf<String>()

    // Tracks the highest-risk event seen while the user is inside a single conversation.
    // Only the first MEDIUM+ detection per session is saved to DB; subsequent detections
    // update the in-memory best result so the guardian alert always reflects the worst seen.
    // convHash → eventId of the one DB record written this session (main-thread only).
    // Cleared on conversation exit so the next visit starts fresh.
    private val sessionRecords     = mutableMapOf<String, Long>()
    // convHashes that have already had a guardian alert sent this session — prevents
    // duplicate alerts when the score improves across multiple messages.
    private val alertedConvHashes             = mutableSetOf<String>()
    private var activeConvHash: String? = null

    private val targetPackages = setOf(
        "com.whatsapp",
        "com.whatsapp.w4b",
        "com.instagram.android",
        "com.google.android.apps.messaging",
        "com.samsung.android.messaging",
        "com.android.messaging",
        "com.android.mms"
    )

    private val modelAvailableReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action != ACTION_MODEL_AVAILABLE) return
            android.util.Log.i(TAG, "Model available broadcast received — hot-loading Gemma")
            loadGemmaAsync()
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        val app = application as HitaApplication
        consentManager           = ConsentManager(this)
        classifier               = OnDeviceClassifier()
        riskScorer               = RiskScorer(
            classifier              = classifier,
            userCategoryProvider    = { consentManager.userCategory },
            riskThresholdsProvider  = { RemoteConfig.riskThresholds }
        )
        localNotificationManager = LocalNotificationManager(this)
        guardianAlertSender      = GuardianAlertSender(this, consentManager)
        riskEventStore           = RiskEventStore(app.database.riskEventDao())
        contactNameDao           = app.database.contactNameDao()
        antiCoercionMonitor      = AntiCoercionMonitor(this, consentManager)

        dedupPrefs = getSharedPreferences(DEDUP_PREFS, MODE_PRIVATE)
        seenTracker = SeenMessageTracker(
            load = { key -> dedupPrefs.getStringSet(key, emptySet())!! },
            save = { key, hashes -> dedupPrefs.edit().putStringSet(key, hashes).apply() }
        )

        // Clear per-conversation dedup state from previous sessions so that messages
        // visible on reconnect (e.g. after a crash or a replace-install that preserves
        // SharedPreferences) are not silently skipped. persistConvState is called before
        // the analysis coroutine launches, so a crash mid-inference leaves stale Layer 1
        // (last_*) and Layer 2 (seen_*) entries that would block the same message forever.
        // Disappearing-messages flags (disappearing_*) are intentionally kept — they track
        // whether we've already fired that specific alert for a conversation.
        dedupPrefs.edit().also { ed ->
            dedupPrefs.all.keys
                .filter { it.startsWith(CONV_KEY_PREFIX) || it.startsWith(SEEN_KEY_PREFIX) }
                .forEach { ed.remove(it) }
        }.apply()

        android.util.Log.i(TAG, "Accessibility service connected — monitoring active")

        // Pin the process as a foreground service so Samsung's FreecessController cannot
        // freeze it between accessibility events. Without this, Samsung OneUI treats the
        // process as a cached background app and repeatedly freezes it (LEV/cached reason).
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(NOTIFICATION_ID_STATUS, localNotificationManager.buildStatusNotification(),
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID_STATUS, localNotificationManager.buildStatusNotification())
        }

        writeHeartbeat()
        mainHandler.postDelayed(heartbeatRunnable, HEARTBEAT_INTERVAL_MS)
        TelemetryManager.get(this).track("monitoring_enabled")
        TelemetryManager.get(this).track("service_connect_ms", (System.currentTimeMillis() - app.startMs).toDouble())

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(modelAvailableReceiver, IntentFilter(ACTION_MODEL_AVAILABLE), RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(modelAvailableReceiver, IntentFilter(ACTION_MODEL_AVAILABLE))
        }

        loadGemmaAsync()

        // Tune service info at runtime to ensure window content retrieval is enabled
        serviceInfo = serviceInfo?.also {
            it.flags = it.flags or
                    AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                    AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
        }
    }

    private fun loadGemmaAsync() {
        serviceScope.launch {
            withContext(Dispatchers.IO) {
                // Guards against loading a second native engine when this is triggered
                // more than once (both onServiceConnected and modelAvailableReceiver call
                // this) — upgrade() also closes any previous instance defensively, but
                // skipping the reload entirely avoids the wasted work and the brief
                // window where two engines are alive at once.
                if (classifier.isLoaded) {
                    android.util.Log.d(TAG, "Gemma already loaded — skipping redundant load")
                    // Tracked (not just logged) so we can see in aggregate, across the fleet,
                    // how often this service is being restarted and re-triggering a load
                    // attempt — the mechanism behind the native crashes this guard fixes.
                    // A rising count here is an early-warning signal even before any crash.
                    TelemetryManager.get(this@HitaAccessibilityService).track("gemma_reload_skipped")
                    return@withContext
                }
                val loadStart = System.currentTimeMillis()
                val gemma = OnDeviceClassifier(this@HitaAccessibilityService)
                val telemetry = TelemetryManager.get(this@HitaAccessibilityService)
                when {
                    gemma.isLoaded -> {
                        classifier.upgrade(gemma)
                        telemetry.track("gemma_load_success")
                        telemetry.track("gemma_load_ms", (System.currentTimeMillis() - loadStart).toDouble())
                        getSharedPreferences(AI_PREFS, MODE_PRIVATE).edit()
                            .putBoolean(KEY_GEMMA_LOADED, true)
                            .putBoolean(KEY_GEMMA_FAILED, false)
                            .apply()
                        android.util.Log.i(TAG, "Gemma ready — ML-assisted mode active")
                    }
                    gemma.loadFailed -> {
                        telemetry.track("gemma_load_failed")
                        telemetry.track("gemma_load_ms", (System.currentTimeMillis() - loadStart).toDouble())
                        getSharedPreferences(AI_PREFS, MODE_PRIVATE).edit()
                            .putBoolean(KEY_GEMMA_LOADED, false)
                            .putBoolean(KEY_GEMMA_FAILED, true)
                            .apply()
                        android.util.Log.w(TAG, "Gemma load failed — rules-only mode")
                    }
                    else -> {
                        android.util.Log.i(TAG, "Gemma not installed — rules-only mode")
                    }
                }
            }
        }
    }

    override fun onInterrupt() {
        android.util.Log.w(TAG, "Accessibility service interrupted")
    }

    override fun onDestroy() {
        super.onDestroy()
        mainHandler.removeCallbacks(heartbeatRunnable)
        runCatching { unregisterReceiver(modelAvailableReceiver) }
        pendingRunnables.values.forEach { mainHandler.removeCallbacks(it) }
        pendingRunnables.clear()
        flushAllPendingAlerts()
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } else {
            @Suppress("DEPRECATION") stopForeground(true)
        }
        localNotificationManager.dismissStatusIndicator()
        TelemetryManager.get(this).flush()
        // Cancel first so no new inference work starts against a classifier we're about
        // to close, then release the native Gemma engine. Without this, OneUI's frequent
        // freeze/restart of this service (see onServiceConnected) left the previous
        // instance's native LlmInference engine loaded forever, since loadGemmaAsync()
        // always creates a brand new one on the next connect. Two live native engines in
        // one process is consistent with the SIGABRT/SIGSEGV crashes seen in production
        // inside libllm_inference_engine_jni.so.
        serviceScope.cancel()
        if (::classifier.isInitialized) classifier.close()
    }

    private fun writeHeartbeat() {
        getSharedPreferences(AI_PREFS, MODE_PRIVATE)
            .edit().putLong(KEY_SERVICE_LAST_ALIVE, System.currentTimeMillis()).apply()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        val pkg = event.packageName?.toString() ?: return
        // Ignore events from non-target packages entirely — notifications, system UI,
        // overlays, etc. all fire here and must NOT trigger a flush, as that would
        // cause repeated alert sends while the user is still in the conversation.
        // Flushing is handled by processWindow (back-to-chat-list / conv switch)
        // and onDestroy.
        if (pkg !in targetPackages) return
        if (!consentManager.isOnboardingComplete) return

        when (event.eventType) {
            // Compose-based apps (Google Messages) haven't finished rendering when
            // TYPE_WINDOW_STATE_CHANGED fires. Schedule processing with a 400 ms
            // fallback; TYPE_WINDOW_CONTENT_CHANGED replaces any pending runnable
            // with a 1500 ms trailing debounce (battery: avoids re-traversing the
            // tree on every keystroke). Either path can therefore process a window
            // whose header subtitle hasn't loaded yet — the alert-time group
            // re-check in processWindow covers that race.
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                pendingRunnables.remove(pkg)?.let { mainHandler.removeCallbacks(it) }
                val r = Runnable { processWindow(pkg) }
                pendingRunnables[pkg] = r
                mainHandler.postDelayed(r, 400)
            }
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED -> {
                pendingRunnables.remove(pkg)?.let { mainHandler.removeCallbacks(it) }
                val r = Runnable { processWindow(pkg) }
                pendingRunnables[pkg] = r
                mainHandler.postDelayed(r, 1500)
            }
        }
    }

    // -------------------------------------------------------------------------
    // Window processing
    // -------------------------------------------------------------------------

    private fun processWindow(packageName: String) {
        val root = rootInActiveWindow ?: return
        try {
            // Must be in a conversation screen — bail out on list/home screens
            if (!isConversationScreen(root, packageName)) {
                if (BuildConfig.DEBUG && packageName == "com.instagram.android") {
                    android.util.Log.w(TAG_IG_DIAG, "isConversationScreen=false — dumping hierarchy")
                    dumpHierarchy(root, "", 0)
                }
                // User navigated back to chat list — flush pending alert for this app
                activeConvHash?.let { flushPendingAlert(it) }
                activeConvHash = null
                parsingFailureTrackedPackages.remove(packageName)
                return
            }

            // Skip group chats
            if (isGroupConversation(root, packageName)) {
                android.util.Log.d(TAG, "[$packageName] Group conversation — skipping")
                return
            }

            val contactName = extractContactName(root, packageName)
                ?: run {
                    if (BuildConfig.DEBUG && packageName == "com.instagram.android") {
                        android.util.Log.w(TAG_IG_DIAG, "contactName=null — dumping hierarchy")
                        dumpHierarchy(root, "", 0)
                    }
                    android.util.Log.d(TAG, "[$packageName] Could not determine contact name — skipping")
                    if (parsingFailureTrackedPackages.add(packageName)) {
                        trackParsingFailure(packageName, root)
                    }
                    return
                }

            val convHash = sha256("$packageName|$contactName")

            // Persist the display name locally so the UI can show it on this device.
            // The hash sent in alerts never changes — only the local DB gains the name mapping.
            serviceScope.launch {
                contactNameDao.upsert(ContactNameEntry(sha256(contactName), contactName))
            }

            // If the user switched to a different conversation within the same app, flush the old one
            if (activeConvHash != null && activeConvHash != convHash) {
                flushPendingAlert(activeConvHash!!)
            }
            activeConvHash = convHash

            // ── Disappearing messages detection ────────────────────────────────
            // Runs before the messages-empty check: the vanish/disappearing banner
            // is a UI-level signal independent of whether any new text is visible.
            //
            // Flagging policy:
            //   Short timer (≤7 days): HIGH — targeted per-contact activation.
            //   Long timer (>7 days) + active threat this session: MEDIUM amplifier.
            //   Long timer + no threat: suppress (global default, not harmful on its own).
            //
            // The persistent dedup key is only set when we fire, so a suppressed
            // conversation is re-evaluated each session and can be upgraded to MEDIUM
            // once a threat is detected. The in-memory suppression set prevents
            // redundant scans within a session when no threat has developed yet.
            val disappearingKey = "$DISAPPEARING_KEY_PREFIX$convHash"
            val alreadyFlagged = dedupPrefs.getBoolean(disappearingKey, false)
            val alreadySuppressed = convHash in disappearingMessagesSuppressed
            val hasExistingThreat = sessionRecords.containsKey(convHash)
            if (!alreadyFlagged && (!alreadySuppressed || hasExistingThreat)) {
                val matchedText = detectDisappearingMessages(root)
                if (matchedText != null) {
                    val durationDays = com.agenthita.sdk.detection.parseDurationDays(matchedText)
                    val riskLevel = com.agenthita.sdk.detection.disappearingRiskLevel(durationDays, hasExistingThreat)
                    if (riskLevel != null) {
                        dedupPrefs.edit().putBoolean(disappearingKey, true).apply()
                        disappearingMessagesSuppressed.remove(convHash)
                        if (BuildConfig.DEBUG) android.util.Log.i(TAG, "[$packageName] Disappearing messages: contact=$contactName duration=${durationDays}d risk=$riskLevel")
                        localNotificationManager.showDisappearingMessagesWarning()
                        val explanation = if (riskLevel == RiskLevel.HIGH)
                            "Contact enabled disappearing messages"
                        else
                            "Contact has disappearing messages enabled alongside detected risk"
                        val syntheticResult = com.agenthita.sdk.detection.DetectionResult(
                            category    = com.agenthita.sdk.detection.HarmCategory.DISAPPEARING_MESSAGES,
                            riskLevel   = riskLevel,
                            score       = if (riskLevel == RiskLevel.HIGH) 1.0f else 0.75f,
                            signals     = listOf(com.agenthita.sdk.detection.SignalMatch("activation_confirmed", "disappearing messages detected", 0.95f)),
                            explanation = explanation
                        )
                        serviceScope.launch {
                            val eventId = riskEventStore.save(
                                appPackage        = packageName,
                                contactIdentifier = contactName,
                                result            = syntheticResult
                            )
                            val analysis = classifier.generateAnalysis(
                                lastMessage = "Disappearing messages mode was activated in this conversation.",
                                context     = emptyList(),
                                signals     = listOf("activation_confirmed"),
                                category    = com.agenthita.sdk.detection.HarmCategory.DISAPPEARING_MESSAGES
                            )
                            riskEventStore.updateGemmaAnalysis(eventId, analysis)
                            if (riskLevel == RiskLevel.HIGH) {
                                withContext(kotlinx.coroutines.Dispatchers.Main) {
                                    val sending = guardianAlertSender.sendIfConfigured(
                                        result      = syntheticResult,
                                        eventId     = eventId,
                                        packageName = packageName,
                                        contactHash = sha256(contactName)
                                    )
                                    if (sending) riskEventStore.markAlertSent(eventId)
                                }
                            }
                        }
                    } else {
                        disappearingMessagesSuppressed.add(convHash)
                        if (BuildConfig.DEBUG) android.util.Log.d(TAG, "[$packageName] Disappearing messages suppressed — long default timer (${durationDays}d), no active threat")
                    }
                }
            }

            val (messages, outgoingTexts) = extractMessages(root, packageName)
            if (messages.isEmpty()) {
                if (BuildConfig.DEBUG) android.util.Log.d(TAG, "[$packageName] no text messages extracted (media-only or empty) — skipping")
                if (BuildConfig.DEBUG && packageName == "com.instagram.android") {
                    android.util.Log.w(TAG_IG_DIAG, "messages=empty for contact=$contactName — dumping hierarchy")
                    dumpHierarchy(root, "", 0)
                }
                // Empty extraction on a confirmed conversation screen may be a benign
                // media-only view — or a silent selector regression (Instagram's Compose
                // migration produced exactly this). Track it (suffix keeps it separate
                // from hard parse failures; once per conversation session to avoid
                // flooding) so a per-app spike is visible on the dashboard.
                if (extractionEmptyTracked.add(convHash)) {
                    trackParsingFailure(packageName, root, "_empty")
                }
                return
            }

            // Per-conversation dedup — two-layer guard:
            //
            // Layer 1 (fast path): if the last visible message text is identical to the
            // one we last processed for this contact, the window hasn't changed at all.
            //
            // Layer 2 (unseen set): collect every message whose hash is not in the
            // per-conversation seen set. Each unseen message is scored individually so
            // a risky message can never be silently skipped by arriving in the same
            // window snapshot as a later, harmless message.
            val lastMessage  = messages.last()
            val convStateKey = "$CONV_KEY_PREFIX$convHash"
            val seenKey      = "$SEEN_KEY_PREFIX$convHash"

            // Layer 1 — compares hashes only; raw message text is never persisted to disk.
            val lastMessageHash = sha256(lastMessage)
            val prevLastMessageHash = dedupPrefs.getString(convStateKey, null)
            if (lastMessageHash == prevLastMessageHash) return

            // Layer 2 — find every message not yet scored
            val unseenMessages = seenTracker.filterUnseen(seenKey, messages) { sha256(it) }
            val unseenOutgoing = unseenMessages.filter { it in outgoingTexts }

            if (unseenMessages.isEmpty()) {
                android.util.Log.d(TAG, "[$packageName] Scroll-back detected — skipping already-seen messages")
                return
            }

            // Persist dedup state for all unseen messages before analysis so that
            // re-entrant events during the coroutine are also suppressed.
            persistConvState(convStateKey, lastMessageHash)
            seenTracker.markSeen(seenKey, unseenMessages) { sha256(it) }

            if (BuildConfig.DEBUG) android.util.Log.d(TAG, "[$packageName] Contact=$contactName ${unseenMessages.size} new msg(s), latest=\"${lastMessage.take(60)}\"")

            // Safe-exit check on latest message
            val safeExit = antiCoercionMonitor.checkForSafeExitIntent(lastMessage)
            if (safeExit.shouldSuppressAnalysis) return

            serviceScope.launch {
                val telemetry = TelemetryManager.get(this@HitaAccessibilityService)
                telemetry.track("analysis_started")
                val startMs = System.currentTimeMillis()

                // Score all unseen messages as a single concatenated block so that
                // attack signals split across consecutive messages (e.g. "are your
                // parents home?" followed by "come meet me") are caught together.
                // Previously seen messages become the context window for mild boosting.
                // Each message is prefixed with [CONTACT] or [USER] so Gemma can
                // distinguish incoming from outgoing when assessing harm direction.
                //
                // Truncation keeps the NEWEST content: a live sextortion script went
                // unscored on 2026-07-19 because .take(300) kept the FIRST 300 chars —
                // a long benign announcement at the top of the window — and cut off the
                // attack lines beneath it. Coercion escalates toward the end of a
                // window; the opener is what we can afford to lose (same rationale as
                // GemmaClassifier.buildFittedPrompt).
                val unseenText = com.agenthita.app.model.GemmaClassifier.keepNewest(
                    unseenMessages.joinToString("\n") { msg ->
                        if (msg in outgoingTexts) "[USER]: $msg" else "[CONTACT]: $msg"
                    },
                    RemoteConfig.gemmaInputTruncationChars
                )
                val seenMessages = (messages - unseenMessages.toSet())
                    .takeLast(MAX_SEEN_MESSAGES_FOR_CONTEXT)
                    .map { msg -> if (msg in outgoingTexts) "[USER]: $msg" else "[CONTACT]: $msg" }

                val results = try {
                    riskScorer.score(unseenText, seenMessages)
                } catch (e: Exception) {
                    telemetry.track("analysis_failed")
                    android.util.Log.e(TAG, "[$packageName] Scoring failed: ${e.message}")
                    return@launch
                }

                val durationMs = System.currentTimeMillis() - startMs
                val topResult  = riskScorer.highestRisk(results)

                telemetry.track("analysis_completed")
                telemetry.track("analysis_duration_ms", durationMs.toDouble())

                if (topResult == null) {
                    android.util.Log.d(TAG, "[$packageName] No risk detected — ${unseenMessages.size} new msg(s)")
                    return@launch
                }

                android.util.Log.d(TAG, "[$packageName] Score=${topResult.score} level=${topResult.riskLevel}")

                // Group re-check at alert time: the group-header subtitle populates
                // asynchronously, so the pre-scoring isGroupConversation gate can miss
                // a group on the first window after chat-open. By the time scoring
                // (and Gemma) finish, the header has loaded — positively identifying
                // a group now means this window slipped through that race, and groups
                // are never alerted on. Suppression requires BOTH the group
                // identification AND that the window still shows the same
                // conversation (hash match), so a genuine 1-1 alert can never be
                // dropped because the user navigated to a group meanwhile.
                if (topResult.riskLevel >= RiskLevel.MEDIUM) {
                    val suppressAsGroup = withContext(kotlinx.coroutines.Dispatchers.Main) {
                        rootInActiveWindow?.let { liveRoot ->
                            extractContactName(liveRoot, packageName)
                                ?.let { sha256("$packageName|$it") } == convHash &&
                                isGroupConversation(liveRoot, packageName)
                        } ?: false
                    }
                    if (suppressAsGroup) {
                        android.util.Log.i(TAG, "[$packageName] Group identified at alert time — suppressing (subtitle loaded after scoring pass)")
                        return@launch
                    }
                }

                // Notification fires immediately for every new risky message, unless the user
                // has opted into HIGH-risk-only notifications — MEDIUM is still recorded and
                // shown in the dashboard below regardless, this only gates the interruption.
                // setOnlyAlertOnce(true) in LocalNotificationManager ensures only one
                // heads-up banner per conversation — subsequent detections silently
                // update the existing notification without making noise.
                val shouldNotify = topResult.riskLevel == RiskLevel.HIGH ||
                    (topResult.riskLevel == RiskLevel.MEDIUM && !consentManager.notifyOnlyHighRiskEnabled)
                if (shouldNotify) {
                    localNotificationManager.showWarning(topResult)
                    telemetry.track("alert_generated")
                }

                if (topResult.riskLevel < RiskLevel.MEDIUM) return@launch

                // ── One DB record per session ──────────────────────────────────────
                val existingEventId = withContext(kotlinx.coroutines.Dispatchers.Main) {
                    sessionRecords[convHash]
                }

                // All new messages were sent by the user → attribute threat to the monitored
                // person's name (set in Guardian Setup), falling back to "You" if not configured.
                // If any incoming messages are also new, the contact is the threat source.
                // Backstop: only attribute to the user when the window actually contains both
                // directions — a window where every message reads outgoing means direction
                // detection is not discriminating (e.g. bounds captured mid-animation), and
                // mis-blaming the monitored person is the costlier error, so default to the
                // contact.
                val senderLabel = consentManager.monitoredUserName ?: "You"
                val directionDiscriminates = outgoingTexts.size < messages.size
                val contactIdentifier =
                    if (directionDiscriminates && unseenOutgoing.size == unseenMessages.size) senderLabel
                    else contactName
                if (contactIdentifier == senderLabel) {
                    contactNameDao.upsert(ContactNameEntry(sha256(senderLabel), senderLabel))
                }

                val eventId: Long
                if (existingEventId == null) {
                    eventId = riskEventStore.save(
                        appPackage        = packageName,
                        contactIdentifier = contactIdentifier,
                        result            = topResult
                    )
                    android.util.Log.d(TAG, "[$packageName] Session event $eventId saved (gemmaLoaded=${classifier.isLoaded})")

                    withContext(kotlinx.coroutines.Dispatchers.Main) {
                        if (activeConvHash == convHash) sessionRecords[convHash] = eventId
                    }

                    // Runs independently of the guardian-alert dispatch below: the analysis
                    // text is dashboard-only (EventDetailActivity) and is never part of the
                    // guardian email payload (see GuardianAlertSender.sendAlert — category,
                    // riskLevel, and a static per-category action list only), so a HIGH alert
                    // must not wait on this second, slower Gemma call.
                    serviceScope.launch {
                        val signalNames = topResult.signals.map { it.signal }.distinct()
                        val analysis = classifier.generateAnalysis(unseenText, seenMessages, signalNames, topResult.category)
                        riskEventStore.updateGemmaAnalysis(eventId, analysis)
                    }
                } else {
                    eventId = existingEventId
                    if (classifier.isLoaded) {
                        serviceScope.launch {
                            val signalNames = topResult.signals.map { it.signal }.distinct()
                            val analysis = classifier.generateAnalysis(unseenText, seenMessages, signalNames, topResult.category)
                            riskEventStore.updateGemmaAnalysis(eventId, analysis)
                            android.util.Log.d(TAG, "[$packageName] Gemma analysis refreshed for event $eventId")
                        }
                    } else {
                        android.util.Log.d(TAG, "[$packageName] Session already has event $eventId — skipping DB save")
                    }
                }

                // ── Guardian alert (HIGH only, immediate) ─────────────────────────
                // Sent immediately on first HIGH result per session. alertedConvHashes
                // deduplicates within a session; it is cleared on conversation exit so
                // a future return to the same contact starts fresh. We do NOT gate on
                // activeConvHash — if the user pressed Home just before the coroutine
                // completed, the risk was still real and the alert should still fire.
                //
                // suppressGuardianAlert: set by RiskScorer when a HIGH result is driven
                // by cross-message context whose prior messages already scored HIGH by
                // rules — meaning a guardian alert was already sent for those messages.
                // We intentionally do NOT add to alertedConvHashes when suppressing so
                // that a genuinely new threat category in the same session can still fire.
                if (topResult.riskLevel == RiskLevel.HIGH) {
                    withContext(kotlinx.coroutines.Dispatchers.Main) {
                        if (convHash !in alertedConvHashes) {
                            if (topResult.suppressGuardianAlert) {
                                android.util.Log.d(TAG, "[$packageName] HIGH via context — guardian alert suppressed (prior messages already alerted)")
                            } else {
                                alertedConvHashes.add(convHash)
                                android.util.Log.i(TAG, "[$packageName] HIGH risk — sending guardian alert: score=${topResult.score}")
                                val sending = guardianAlertSender.sendIfConfigured(
                                    result      = topResult,
                                    eventId     = eventId,
                                    packageName = packageName,
                                    contactHash = sha256(contactName)
                                )
                                if (sending) riskEventStore.markAlertSent(eventId)
                            }
                        }
                    }
                }
            }
        } catch (e: Throwable) {
            // Catch all unchecked exceptions from any per-app parsing helper so a broken
            // selector in one app never crashes the service and silences all other apps.
            val shortPkg = pkgShortName(packageName)
            android.util.Log.e(TAG, "[$packageName] Parsing exception — $shortPkg will be skipped this event: ${e.message}", e)
            if (parsingFailureTrackedPackages.add(packageName)) {
                trackParsingFailure(packageName, root)
            }
        } finally {
            root.recycle()
        }
    }

    private fun parsingFailedEvent(pkg: String) = when (pkg) {
        "com.whatsapp", "com.whatsapp.w4b"         -> "parsing_failed_whatsapp"
        "com.instagram.android"                     -> "parsing_failed_instagram"
        "com.google.android.apps.messaging"         -> "parsing_failed_google_messages"
        "com.samsung.android.messaging"             -> "parsing_failed_samsung_messages"
        "com.android.messaging"                     -> "parsing_failed_aosp_messages"
        "com.android.mms"                           -> "parsing_failed_aosp_mms"
        else                                        -> "parsing_failed_unknown"
    }

    /**
     * Tracks a parsing-failure event (optionally suffixed, e.g. "_empty" for empty
     * extractions) plus, best-effort, any unrecognized view IDs visible on screen at that
     * moment — see [collectUnrecognizedViewIds]. Population-level signal for "what UI
     * element don't we recognize yet," without needing to reproduce the issue by hand.
     */
    private fun trackParsingFailure(packageName: String, root: AccessibilityNodeInfo, suffix: String = "") {
        TelemetryManager.get(this).track("${parsingFailedEvent(packageName)}$suffix")
        collectUnrecognizedViewIds(root, packageName).forEach { viewId ->
            TelemetryManager.get(this).trackViewIdFailure(packageName, viewId)
        }
    }

    /**
     * Walks [root] collecting distinct view-ID names for [packageName] that aren't already
     * covered by any of our known extraction/exclusion lists (RemoteConfig.uiTags). Sent
     * only as an aggregate counter — never message content — via
     * TelemetryManager.trackViewIdFailure, so we can see, across the whole user
     * population, when a supported app introduces UI our extraction code doesn't know
     * about yet. Defensive: never throws, since it runs from within failure-handling
     * paths themselves.
     */
    private fun collectUnrecognizedViewIds(root: AccessibilityNodeInfo, packageName: String): Set<String> =
        runCatching {
            val (knownExact, knownPrefixes) = knownViewIdsFor(packageName)

            val found = mutableSetOf<String>()
            fun walk(node: AccessibilityNodeInfo) {
                val bareId = node.viewIdResourceName?.substringAfterLast("/")
                if (bareId != null && isUnrecognizedViewId(bareId, knownExact, knownPrefixes)) {
                    found.add(bareId)
                }
                for (i in 0 until node.childCount) {
                    val child = node.getChild(i) ?: continue
                    walk(child)
                    child.recycle()
                }
            }
            walk(root)
            found.take(MAX_UNRECOGNIZED_VIEW_IDS_PER_EVENT).toSet()
        }.getOrDefault(emptySet())

    /** Returns a short metric-safe label for a package name. */
    private fun pkgShortName(pkg: String) = when (pkg) {
        "com.whatsapp", "com.whatsapp.w4b"          -> "whatsapp"
        "com.instagram.android"                      -> "instagram"
        "com.google.android.apps.messaging"          -> "google_messages"
        "com.samsung.android.messaging"              -> "samsung_messages"
        "com.android.messaging"                      -> "aosp_messages"
        "com.android.mms"                            -> "aosp_mms"
        else                                         -> pkg.replace('.', '_')
    }

    // -------------------------------------------------------------------------
    // Conversation screen detection
    // -------------------------------------------------------------------------

    /**
     * Returns true only if the current window looks like an open conversation
     * (as opposed to a contact list, settings page, story viewer, etc.)
     */
    private fun isConversationScreen(root: AccessibilityNodeInfo, pkg: String): Boolean {
        return when (pkg) {
            "com.whatsapp", "com.whatsapp.w4b" -> {
                // Require the compose field to be visible — not just present in the tree.
                // In selection/edit-message mode WhatsApp hides the compose area but leaves
                // the node in the hierarchy, which caused "Edit message" to be read as the
                // contact name. isVisibleToUser=false correctly excludes those states.
                val t = RemoteConfig.uiTags
                if (t.waEditBarId.isNotEmpty()) {
                    val editNodes = root.findAccessibilityNodeInfosByViewId("$pkg:id/${t.waEditBarId}")
                    val editing = editNodes.isNotEmpty()
                    editNodes.forEach { it.recycle() }
                    if (editing) return false
                }
                // Media caption editor and the forward/recipient picker both have their own
                // compose box + send button, so they'd otherwise pass the checks below and
                // get misread as a conversation — neither has a contact name or messages,
                // so every screen visit failed extraction and flooded parsing-failure
                // telemetry (color_picker_btn, recipients_scroller, etc. — 2026-08-01).
                if (t.waCaptionEditorMarkerId.isNotEmpty()) {
                    val captionNodes = root.findAccessibilityNodeInfosByViewId("$pkg:id/${t.waCaptionEditorMarkerId}")
                    val inCaptionEditor = captionNodes.isNotEmpty()
                    captionNodes.forEach { it.recycle() }
                    if (inCaptionEditor) return false
                }
                if (t.waRecipientPickerMarkerId.isNotEmpty()) {
                    val recipientNodes = root.findAccessibilityNodeInfosByViewId("$pkg:id/${t.waRecipientPickerMarkerId}")
                    val inRecipientPicker = recipientNodes.isNotEmpty()
                    recipientNodes.forEach { it.recycle() }
                    if (inRecipientPicker) return false
                }
                val entryNodes = root.findAccessibilityNodeInfosByViewId("$pkg:id/${t.waEntryId}")
                val composeVisible = entryNodes.any { it.isVisibleToUser }
                entryNodes.forEach { it.recycle() }
                if (composeVisible) return true
                val sendNodes = root.findAccessibilityNodeInfosByViewId("$pkg:id/${t.waSendId}")
                val sendVisible = sendNodes.any { it.isVisibleToUser }
                sendNodes.forEach { it.recycle() }
                sendVisible
            }
            "com.instagram.android" -> {
                // Composer and send button must be visible — selection/reaction overlays
                // hide the compose area while leaving nodes in the tree.
                val t = RemoteConfig.uiTags
                if (t.igEditBarId.isNotEmpty()) {
                    val editNodes = root.findAccessibilityNodeInfosByViewId("com.instagram.android:id/${t.igEditBarId}")
                    val editing = editNodes.isNotEmpty()
                    editNodes.forEach { it.recycle() }
                    if (editing) return false
                }
                val igComposeIds = listOf(
                    "com.instagram.android:id/${t.igComposerEditTextId}",
                    "com.instagram.android:id/${t.igSendButtonId}",
                    "com.instagram.android:id/${t.igDirectSendButtonId}"
                )
                val composeVisible = igComposeIds.any { id ->
                    val nodes = root.findAccessibilityNodeInfosByViewId(id)
                    val visible = nodes.any { it.isVisibleToUser }
                    nodes.forEach { it.recycle() }
                    visible
                }
                if (composeVisible) return true
                // Recycler view fallback — no compose visibility check needed since
                // it is a content container, not a transient action overlay.
                val recyclerNodes = root.findAccessibilityNodeInfosByViewId(
                    "com.instagram.android:id/${t.igRecyclerViewId}"
                )
                val hasRecycler = recyclerNodes.isNotEmpty()
                recyclerNodes.forEach { it.recycle() }
                hasRecycler
            }
            else -> {
                // SMS apps: compose field must be visible — long-press selection modes
                // in Google Messages and Samsung Messages hide the compose area while
                // keeping its node in the tree, same pattern as WhatsApp.
                val t = RemoteConfig.uiTags
                if (t.gmEditBarId.isNotEmpty()) {
                    val editNodes = root.findAccessibilityNodeInfosByViewId(
                        "com.google.android.apps.messaging:id/${t.gmEditBarId}"
                    )
                    val editing = editNodes.isNotEmpty()
                    editNodes.forEach { it.recycle() }
                    if (editing) return false
                }
                val composeIds = listOf(
                    "com.google.android.apps.messaging:id/compose_message_text",
                    "com.google.android.apps.messaging:id/message_entry_layout",
                    "com.android.messaging:id/compose_message_text",
                    "com.samsung.android.messaging:id/text_editor",
                    "com.android.mms:id/embedded_text_editor",
                    "android:id/input"
                )
                val composeVisible = composeIds.any { id ->
                    val nodes = root.findAccessibilityNodeInfosByViewId(id)
                    val visible = nodes.any { it.isVisibleToUser }
                    nodes.forEach { it.recycle() }
                    visible
                }
                if (composeVisible) return true
                // Message list fallback — visible even in selection mode, but we only
                // reach here if no compose field was found at all (e.g. read-only threads).
                val listIds = listOf(
                    "com.google.android.apps.messaging:id/message_list",
                    "com.android.messaging:id/message_list"
                )
                val hasMessageList = listIds.any { id ->
                    val nodes = root.findAccessibilityNodeInfosByViewId(id)
                    val found = nodes.isNotEmpty()
                    nodes.forEach { it.recycle() }
                    found
                }
                if (hasMessageList) return true
                // Google Messages (Compose builds): uses bare test tags — check for ConversationScreenUi
                val composeTags = mutableListOf<AccessibilityNodeInfo>()
                findNodesByTag(root, RemoteConfig.uiTags.gmConversationScreenTag, composeTags)
                val found = composeTags.isNotEmpty()
                composeTags.forEach { it.recycle() }
                found
            }
        }
    }

    // -------------------------------------------------------------------------
    // Group chat detection
    // -------------------------------------------------------------------------

    private fun isGroupConversation(root: AccessibilityNodeInfo, pkg: String): Boolean {
        return when (pkg) {
            "com.whatsapp", "com.whatsapp.w4b" -> {
                val subtitleNodes = root.findAccessibilityNodeInfosByViewId("$pkg:id/${RemoteConfig.uiTags.waContactStatusId}")
                val subtitleNode = subtitleNodes.firstOrNull()
                val subtitle = subtitleNode?.text?.toString()?.takeIf { it.isNotBlank() }
                    ?: subtitleNode?.contentDescription?.toString() ?: ""
                subtitleNodes.forEach { it.recycle() }
                // Structural signal: per-bubble sender names exist only in group
                // chats. The header subtitle populates asynchronously after the
                // chat opens, so the first processed window often has no subtitle
                // yet — sender names are already in the message list by then.
                val senderNameId = RemoteConfig.uiTags.waGroupSenderNameId
                val hasGroupSenderNames = senderNameId.isNotEmpty() &&
                    root.findAccessibilityNodeInfosByViewId("$pkg:id/$senderNameId")
                        .also { nodes -> nodes.forEach { it.recycle() } }
                        .isNotEmpty()
                isWhatsAppGroupSubtitle(subtitle) || hasGroupSenderNames
            }
            "com.instagram.android" -> {
                val nodes = root.findAccessibilityNodeInfosByViewId("com.instagram.android:id/${RemoteConfig.uiTags.igHeaderSubtitleId}")
                val subtitle = nodes.firstOrNull()?.text?.toString() ?: ""
                nodes.forEach { it.recycle() }
                val isGroup = subtitle.contains("other", ignoreCase = true) ||
                    subtitle.contains("people", ignoreCase = true) ||
                    subtitle.contains("member", ignoreCase = true) ||
                    subtitle.split(",").size >= 3
                if (BuildConfig.DEBUG && isGroup) {
                    android.util.Log.w(TAG_IG_DIAG, "isGroupConversation=true subtitle=\"$subtitle\" — dumping hierarchy")
                    dumpHierarchy(root, "", 0)
                }
                isGroup
            }
            else -> false // SMS doesn't surface group easily from the header; handled below
        }
    }

    // -------------------------------------------------------------------------
    // Contact name extraction
    // -------------------------------------------------------------------------

    private fun extractContactName(root: AccessibilityNodeInfo, pkg: String): String? {
        return when (pkg) {
            "com.whatsapp", "com.whatsapp.w4b" -> {
                val nodes = root.findAccessibilityNodeInfosByViewId("$pkg:id/${RemoteConfig.uiTags.waContactNameId}")
                val node = nodes.firstOrNull()
                // Prefer node.text; fall back to content-desc which WhatsApp formats as
                // "<name>, <status>" (e.g. "Alice, Disappearing messages on") — so strip after comma.
                val name = node?.text?.toString()?.takeIf { it.isNotBlank() }
                    ?: node?.contentDescription?.toString()
                        ?.substringBefore(",")?.trim()?.takeIf { it.isNotBlank() }
                nodes.forEach { it.recycle() }
                // Structural fallback: if the configured view ID is absent (WhatsApp renamed it),
                // walk the toolbar container hierarchy to find the first meaningful text node.
                // conversation_contact / custom_view / toolbar are layout containers that are
                // far more stable across WhatsApp versions than the inner text view IDs.
                name ?: extractWhatsAppContactNameFallback(root, pkg)
            }
            "com.instagram.android" -> {
                val nodes = root.findAccessibilityNodeInfosByViewId("com.instagram.android:id/${RemoteConfig.uiTags.igHeaderTitleId}")
                val name = nodes.firstOrNull()?.text?.toString()
                nodes.forEach { it.recycle() }
                name
            }
            else -> {
                // SMS apps — look for action bar title
                val ids = listOf(
                    "com.google.android.apps.messaging:id/conversation_title",
                    "com.android.messaging:id/conversation_title",
                    "com.samsung.android.messaging:id/toolbar_title",
                    "android:id/action_bar_title"
                )
                for (id in ids) {
                    val nodes = root.findAccessibilityNodeInfosByViewId(id)
                    val name = nodes.firstOrNull()?.text?.toString()
                    nodes.forEach { it.recycle() }
                    if (!name.isNullOrBlank()) return name
                }
                // Google Messages (Compose builds): contact name sits inside a node tagged
                // "top_app_bar_title_row" with no package prefix.
                val t = RemoteConfig.uiTags
                val titleRowNodes = mutableListOf<AccessibilityNodeInfo>()
                findNodesByTag(root, t.gmTitleRowTag, titleRowNodes)
                for (row in titleRowNodes) {
                    val name = extractTextFromChildren(row)
                    row.recycle()
                    if (!name.isNullOrBlank()) return name
                }
                // Last resort: parse sender from content-desc of message_text nodes.
                // Format: "<contact> said <message>" — present in Google Messages Compose UI.
                val msgNodes = mutableListOf<AccessibilityNodeInfo>()
                findNodesByTag(root, t.gmMessageTag, msgNodes)
                val name = msgNodes.firstNotNullOfOrNull { node ->
                    val desc = node.contentDescription?.toString() ?: ""
                    val match = Regex("^(.+?) said .+").find(desc)
                    match?.groupValues?.get(1)?.takeIf { it != "You" && it.isNotBlank() }
                }
                msgNodes.forEach { it.recycle() }
                name
            }
        }
    }

    /**
     * Structural fallback for WhatsApp contact name when the configured view ID is absent.
     * Walks stable container IDs (conversation_contact → custom_view → toolbar) looking
     * for the first non-chrome TextView. These containers change far less often across
     * WhatsApp versions than the inner text node IDs.
     */
    private fun extractWhatsAppContactNameFallback(root: AccessibilityNodeInfo, pkg: String): String? {
        for (containerId in listOf("conversation_contact", "custom_view", "toolbar")) {
            val containers = root.findAccessibilityNodeInfosByViewId("$pkg:id/$containerId")
            for (container in containers) {
                val name = firstMeaningfulText(container, maxDepth = 5)
                container.recycle()
                if (!name.isNullOrBlank()) return name
            }
            containers.forEach { it.recycle() }
        }
        return null
    }

    private fun firstMeaningfulText(node: AccessibilityNodeInfo, maxDepth: Int): String? {
        if (maxDepth < 0) return null
        val text = node.text?.toString()?.takeIf { it.isNotBlank() && !isUIChrome(it) && it.length >= 2 }
            ?: node.contentDescription?.toString()
                ?.substringBefore(",")?.trim()
                ?.takeIf { it.isNotBlank() && !isUIChrome(it) && it.length >= 2 }
        if (text != null) return text
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = firstMeaningfulText(child, maxDepth - 1)
            child.recycle()
            if (found != null) return found
        }
        return null
    }

    // -------------------------------------------------------------------------
    // Message text extraction
    // -------------------------------------------------------------------------

    private fun AccessibilityNodeInfo.asNodeInfo(): NodeInfo = object : NodeInfo {
        override val viewIdResourceName get() = this@asNodeInfo.viewIdResourceName
        override val text get() = this@asNodeInfo.text
        override val className get() = this@asNodeInfo.className
        override val childCount get() = this@asNodeInfo.childCount
        override val boundsCenterX: Int get() {
            val r = Rect()
            this@asNodeInfo.getBoundsInScreen(r)
            return (r.left + r.right) / 2
        }
        override fun getChild(i: Int): NodeInfo? = this@asNodeInfo.getChild(i)?.asNodeInfo()
    }

    /**
     * Extracts the last up to 5 visible incoming message texts from the screen.
     * Own (outgoing) messages are excluded where they can be identified.
     */
    /**
     * Extracts up to 5 recent messages from the conversation, both incoming and outgoing.
     * Returns all message texts in screen order plus the subset of those texts that were
     * sent by the user (outgoing), so the caller can attribute detections correctly.
     */
    private fun extractMessages(root: AccessibilityNodeInfo, pkg: String): Pair<List<String>, Set<String>> {
        // (text, isOutgoing) — preserved in screen/chronological order
        val raw = mutableListOf<Pair<String, Boolean>>()

        when (pkg) {
            "com.whatsapp", "com.whatsapp.w4b" -> {
                val statusNodes = queryWhatsAppStatusNodes(root, pkg)
                val nodes = root.findAccessibilityNodeInfosByViewId("$pkg:id/${RemoteConfig.uiTags.waMessageTextId}")
                if (BuildConfig.DEBUG) android.util.Log.d(TAG, "[$pkg] extraction: ${nodes.size} text nodes found")
                nodes.forEach { node ->
                    val text = node.text?.toString()
                    val outgoing = isOutgoingWhatsApp(node, statusNodes)
                    val media = text != null && isMediaMessage(text)
                    if (BuildConfig.DEBUG) android.util.Log.d(TAG, "[$pkg] node text=\"${text?.take(40)}\" outgoing=$outgoing media=$media len=${text?.length}")
                    if (!text.isNullOrBlank() && text.length >= MIN_MESSAGE_LENGTH && !media && !isUIChrome(text)) {
                        raw.add(text to outgoing)
                    }
                    node.recycle()
                }
                statusNodes.forEach { it.recycle() }
                // Allowlist fallback: if no message_text nodes are visible (WhatsApp renamed
                // the ID, or — far more commonly — the current viewport simply has no
                // regular text bubbles in it, e.g. it shows only a shared-contact card, a
                // poll, or a voice note), only collect text from the small set of known real
                // message-content view IDs (RemoteConfig.uiTags.waMessageContentIds), never a
                // full-tree walk. This avoids the whole class of "chrome scraped as a
                // message" bugs by construction: WhatsApp UI that isn't on the allowlist
                // (contact-card name/buttons, poll options not yet added, group-sender-name,
                // header chrome, etc.) is simply never visited, rather than needing a new
                // exclusion entry every time a new one is found.
                if (raw.isEmpty()) {
                    if (BuildConfig.DEBUG) android.util.Log.d(TAG, "[$pkg] message_text ID not found — using allowlisted content fallback")
                    collectWhatsAppAllowlistedContent(root, pkg, raw)
                    if (BuildConfig.DEBUG) raw.forEach {
                        android.util.Log.d(TAG, "[$pkg] fallback text=\"${it.first.take(40)}\" outgoing=${it.second}")
                    }
                }
            }
            "com.instagram.android" -> {
                val igTextIds = RemoteConfig.uiTags.igMessageTextIds.map { "com.instagram.android:id/$it" }
                for (viewId in igTextIds) {
                    val nodes = root.findAccessibilityNodeInfosByViewId(viewId)
                    nodes.forEach { node ->
                        val text = node.text?.toString()
                        if (!text.isNullOrBlank() && text.length >= MIN_MESSAGE_LENGTH && !isMediaMessage(text) && !isUIChrome(text)) {
                            raw.add(text to isOutgoingInstagram(node))
                        }
                        node.recycle()
                    }
                    if (raw.isNotEmpty()) break
                }
                // Structural fallback for Compose-rendered messages (MetaComposeView with no-id TextViews).
                // Scope to message_list children via InstagramConversationHelper so the logic is
                // unit-testable without the Android framework. Instagram has renamed the list's
                // view ID across versions ("direct_thread_recycler_view" → "message_list"), so try
                // the configured ID plus the known variants.
                if (raw.isEmpty()) {
                    if (BuildConfig.DEBUG) android.util.Log.d(TAG, "[com.instagram.android] id-based extraction empty — using recycler structural fallback")
                    val igChromeTexts = RemoteConfig.uiTags.igUiChromeTexts
                    val recyclerIds = (listOf(RemoteConfig.uiTags.igRecyclerViewId) +
                        listOf("message_list", "direct_thread_recycler_view")).distinct()
                    for (recyclerId in recyclerIds) {
                        val listNodes = root.findAccessibilityNodeInfosByViewId(
                            "com.instagram.android:id/$recyclerId"
                        )
                        listNodes.forEach { listNode ->
                            val midX = windowMidX(listNode)
                            val messages = InstagramConversationHelper.collectMessagesFromList(
                                listNode.asNodeInfo(),
                                "com.instagram.android:id/message_content"
                            ) { text ->
                                text.length >= MIN_MESSAGE_LENGTH && !isMediaMessage(text) &&
                                    !isUIChrome(text) && text.lowercase() !in igChromeTexts
                            }
                            messages.forEach { raw.add(it.text to (it.centerX > midX)) }
                            listNode.recycle()
                        }
                        if (raw.isNotEmpty()) break
                    }
                }
            }
            else -> {
                // Google Messages (Compose builds): content-desc identifies sender direction.
                val gmNodes = mutableListOf<AccessibilityNodeInfo>()
                findNodesByTag(root, RemoteConfig.uiTags.gmMessageTag, gmNodes)
                if (gmNodes.isNotEmpty()) {
                    gmNodes.forEach { node ->
                        val desc = node.contentDescription?.toString() ?: ""
                        val text = node.text?.toString()
                        if (!text.isNullOrBlank() && text.length >= MIN_MESSAGE_LENGTH &&
                            !isMediaMessage(text) && !isUIChrome(text)) {
                            raw.add(text to desc.startsWith("You said", ignoreCase = true))
                        }
                        node.recycle()
                    }
                } else {
                    // Fallback for other SMS apps (Samsung, AOSP).
                    collectTextViewContent(root, raw)
                }
            }
        }

        val lastFive = raw.takeLast(5)
        val outgoingTexts = lastFive.filter { it.second }.map { it.first }.toSet()
        return lastFive.map { it.first } to outgoingTexts
    }

    private fun isMediaMessage(text: String): Boolean = Companion.isMediaMessage(text)

    /**
     * WhatsApp outgoing messages are right-aligned; incoming are left-aligned.
     * Uses the horizontal center of the node rather than the left edge, because
     * long outgoing bubbles (max ~75% screen width) start left of the midpoint,
     * causing left-bound checks to misclassify them as incoming.
     * Max-width incoming center ≈ (22 + 832)/2 = 427px; outgoing ≈ (248 + 1058)/2 = 653px
     * on a 1080px screen — both safely on opposite sides of the 540px threshold.
     */
    private fun isOutgoingWhatsApp(messageNode: AccessibilityNodeInfo, statusNodes: List<AccessibilityNodeInfo>): Boolean {
        val rect = Rect()
        messageNode.getBoundsInScreen(rect)
        // Structural, position-independent signal: WhatsApp only ever shows a
        // delivery-status indicator (sent/delivered/read ticks) on the user's own
        // outgoing bubbles, never on an incoming one — confirmed on-device via
        // hierarchy dump (2026-08-28): the "status" node sits in the same row as
        // the outgoing bubble only. Checked first since it's immune to the
        // animation-timing glitch documented on windowMidX, where bubble bounds
        // are transiently offset and every message reads as outgoing by position.
        val statusRect = Rect()
        val hasStatusInRow = statusNodes.any { status ->
            status.getBoundsInScreen(statusRect)
            statusRect.top < rect.bottom && statusRect.bottom > rect.top
        }
        if (hasStatusInRow) return true
        return (rect.left + rect.right) / 2 > windowMidX(messageNode)
    }

    /** Queries WhatsApp's delivery-status indicator nodes once per window, reused across
     *  every message bubble in [isOutgoingWhatsApp] rather than re-querying per message. */
    private fun queryWhatsAppStatusNodes(root: AccessibilityNodeInfo, pkg: String): List<AccessibilityNodeInfo> {
        val statusId = RemoteConfig.uiTags.waStatusId
        return if (statusId.isEmpty()) emptyList()
               else root.findAccessibilityNodeInfosByViewId("$pkg:id/$statusId")
    }

    /**
     * Horizontal midpoint of the window containing [node], falling back to the
     * physical screen. Bubble alignment must be judged inside the app window:
     * during the chat-opening slide-in animation (and in split-screen / pop-up
     * view) node bounds are offset from the screen, and a screen-midpoint
     * comparison reads every bubble as outgoing.
     */
    private fun windowMidX(node: AccessibilityNodeInfo): Int {
        val window = node.window ?: return resources.displayMetrics.widthPixels / 2
        val bounds = Rect()
        window.getBoundsInScreen(bounds)
        return if (bounds.width() > 0) (bounds.left + bounds.right) / 2
               else resources.displayMetrics.widthPixels / 2
    }

    /**
     * Instagram outgoing messages are right-aligned; incoming are left-aligned.
     * UI dump confirms: outgoing left-bound ≈ 945px, incoming ≈ 158px on a 1080px screen.
     * Uses center for consistency with WhatsApp, guarding against future layout changes
     * where long outgoing bubbles might push left-bound below the midpoint.
     */
    private fun isOutgoingInstagram(messageNode: AccessibilityNodeInfo): Boolean {
        val rect = Rect()
        messageNode.getBoundsInScreen(rect)
        return (rect.left + rect.right) / 2 > windowMidX(messageNode)
    }

    /**
     * WhatsApp-only fallback for when no message_text nodes are visible — collects text
     * only from the known real message-content view IDs in
     * RemoteConfig.uiTags.waMessageContentIds (an allowlist, not a full-tree walk). See
     * the call site for why this is safer than scraping every TextView on screen.
     */
    private fun collectWhatsAppAllowlistedContent(root: AccessibilityNodeInfo, pkg: String, out: MutableList<Pair<String, Boolean>>) {
        val statusNodes = queryWhatsAppStatusNodes(root, pkg)
        RemoteConfig.uiTags.waMessageContentIds.forEach { contentId ->
            val nodes = root.findAccessibilityNodeInfosByViewId("$pkg:id/$contentId")
            nodes.forEach { node ->
                val text = node.text?.toString()
                if (!text.isNullOrBlank() && text.length >= MIN_MESSAGE_LENGTH &&
                    !isMediaMessage(text) && !isUIChrome(text)) {
                    out.add(text to isOutgoingWhatsApp(node, statusNodes))
                }
                node.recycle()
            }
        }
        statusNodes.forEach { it.recycle() }
    }

    /**
     * Generic text collection for SMS apps — traverse tree and collect all
     * TextView-like content that looks like a message (long enough, not a label).
     * Each entry is (text, isOutgoing) using position-based direction detection.
     * Nodes whose view ID marks them as conversation chrome are skipped — those
     * carry arbitrary text (names, dates) that text filters cannot catch.
     */
    private fun collectTextViewContent(node: AccessibilityNodeInfo, out: MutableList<Pair<String, Boolean>>) {
        val text = node.text?.toString()
        if (!text.isNullOrBlank() &&
            text.length >= MIN_MESSAGE_LENGTH &&
            node.className?.contains("TextView") == true &&
            !isFallbackChromeId(node.viewIdResourceName, RemoteConfig.uiTags.waFallbackExcludedIdPrefixes) &&
            !isMediaMessage(text) &&
            !isUIChrome(text)
        ) {
            out.add(text to isOutgoingGeneric(node))
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            collectTextViewContent(child, out)
            child.recycle()
        }
    }

    private fun isOutgoingGeneric(node: AccessibilityNodeInfo): Boolean {
        val rect = Rect()
        node.getBoundsInScreen(rect)
        return rect.left > windowMidX(node)
    }

    // -------------------------------------------------------------------------
    // Disappearing messages detection
    // -------------------------------------------------------------------------

    /**
     * Returns the matched node's text if any visible node in [root] matches a known
     * disappearing/vanish mode activation phrase, null otherwise.
     * The text is returned so the caller can extract the timer duration from it.
     * Depth-limited to 12 levels to stay fast on the main thread.
     */
    private fun detectDisappearingMessages(root: AccessibilityNodeInfo): String? =
        scanNodeForOnPatterns(root, 0)

    private fun scanNodeForOnPatterns(node: AccessibilityNodeInfo, depth: Int): String? {
        if (depth > 12) return null
        val text = (node.text?.toString() ?: node.contentDescription?.toString())
            ?.lowercase() ?: ""
        if (text.isNotBlank() && isDisappearingActivationText(text)) {
            // The trigger phrase and the timer duration (e.g. "90 days") can render as
            // sibling nodes under a shared container — WhatsApp's banner has a bold
            // "Change timer" link as its own node, which means the surrounding sentence
            // is sometimes split too. Widen to the parent's full text so a duration
            // living in a sibling node is still visible to parseDurationDays(); without
            // this, a long/default timer whose digits fall outside the matched node
            // parses as unparseable and falls through to the HIGH default meant for a
            // genuinely short timer.
            val parent = node.parent
            val widened = if (parent != null) {
                val collected = StringBuilder()
                collectAllText(parent, collected, 0)
                parent.recycle()
                collected.toString().lowercase().ifBlank { text }
            } else text
            return widened
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = scanNodeForOnPatterns(child, depth + 1)
            child.recycle()
            if (found != null) return found
        }
        return null
    }

    private fun collectAllText(node: AccessibilityNodeInfo, out: StringBuilder, depth: Int) {
        if (depth > 12) return
        val t = node.text?.toString() ?: node.contentDescription?.toString()
        if (!t.isNullOrBlank()) {
            if (out.isNotEmpty()) out.append(' ')
            out.append(t)
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            collectAllText(child, out, depth + 1)
            child.recycle()
        }
    }

    private fun isUIChrome(text: String): Boolean =
        isUIChrome(text, MIN_MESSAGE_LENGTH, RemoteConfig.uiTags.gmUiChromePrefixes)

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    /**
     * Persists the SHA-256 hash of the last-analyzed message for a conversation key —
     * never the raw message text, so nothing from the conversation is written to disk.
     * Evicts excess entries (oldest by insertion order is not guaranteed in SharedPreferences,
     * so we just trim any entries beyond the cap to keep the prefs file lean).
     */
    private fun persistConvState(key: String, lastMessageHash: String) {
        val prefs = dedupPrefs
        val editor = prefs.edit()
        val all = prefs.all
        if (all.size >= DEDUP_MAX_ENTRIES) {
            all.keys
                .take(all.size - DEDUP_MAX_ENTRIES + 1)
                .forEach { editor.remove(it) }
        }
        editor.putString(key, lastMessageHash).apply()
    }

    /**
     * Ends the conversation session: clears the one-save-per-session record so a future
     * visit to the same conversation starts fresh, dismisses the warning notification so
     * the next conversation's alert shows as a fresh heads-up, then sends one guardian
     * alert if a HIGH-risk result was accumulated during the session.
     */
    /** Resets per-session state when the user leaves a conversation. */
    private fun flushPendingAlert(convHash: String) {
        sessionRecords.remove(convHash)
        alertedConvHashes.remove(convHash)
        disappearingMessagesSuppressed.remove(convHash)
        extractionEmptyTracked.remove(convHash)
        // disappearing-messages dedup lives in dedupPrefs (persistent) — not cleared here
        // so switching apps or restarting the service never re-fires the same alert.
        // seen_* is intentionally NOT cleared here. New messages are not yet in seen_*
        // by definition, so they will be scored on the next visit. Clearing seen_* would
        // cause already-scored messages to look new on every re-entry and fire duplicate
        // guardian alerts. seen_* is trimmed at MAX_SEEN_PER_CONV and reset on service
        // reconnect, so it does not grow unboundedly.
        localNotificationManager.dismissWarning()
    }

    private fun flushAllPendingAlerts() {
        sessionRecords.keys.toList().forEach { flushPendingAlert(it) }
    }

    private fun extractTextFromChildren(node: AccessibilityNodeInfo): String? {
        val text = node.text?.toString()
        if (!text.isNullOrBlank()) return text
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = extractTextFromChildren(child)
            child.recycle()
            if (!found.isNullOrBlank()) return found
        }
        return null
    }

    /**
     * Walks the accessibility tree and collects all nodes whose viewIdResourceName
     * equals [tag] exactly. Used for Jetpack Compose UIs (e.g. Google Messages) that
     * expose bare test-tag strings instead of "package:id/name" resource IDs.
     */
    private fun findNodesByTag(
        node: AccessibilityNodeInfo,
        tag: String,
        out: MutableList<AccessibilityNodeInfo>,
        depth: Int = 0
    ) {
        if (depth > 20) return
        if (node.viewIdResourceName == tag) out.add(node)
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            findNodesByTag(child, tag, out, depth + 1)
            if (node.viewIdResourceName != tag) child.recycle()
        }
    }

    private fun sha256(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }

    // -------------------------------------------------------------------------
    // Diagnostic hierarchy dump (Instagram debug only)
    // -------------------------------------------------------------------------

    /**
     * Logs the full view hierarchy to logcat under TAG_IG_DIAG so you can see
     * the real view IDs exposed by the installed Instagram version.
     *
     * Filter in logcat: tag:HitaIG
     *
     * Each line format:
     *   <indent>[viewId] className  text="…"  desc="…"
     *
     * Only fires when Instagram detection fails — remove or guard with a build
     * flag before shipping to production (raw node text leaks to logcat).
     */
    private fun dumpHierarchy(node: AccessibilityNodeInfo, indent: String, depth: Int) {
        if (depth > 8) return
        val viewId   = node.viewIdResourceName ?: "(no-id)"
        val cls      = node.className?.toString()?.substringAfterLast('.') ?: "?"
        val text     = node.text?.toString()?.take(60)?.let { "text=\"$it\"" } ?: ""
        val desc     = node.contentDescription?.toString()?.take(60)?.let { "desc=\"$it\"" } ?: ""
        val hint     = node.hintText?.toString()?.take(40)?.let { "hint=\"$it\"" } ?: ""
        android.util.Log.d(TAG_IG_DIAG, "$indent[$viewId] $cls  $text  $desc  $hint".trimEnd())
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            dumpHierarchy(child, "$indent  ", depth + 1)
            child.recycle()
        }
    }

}

